from scrapy import cmdline

cmdline.execute("scrapy crawl beijing_tender_spider".split())
cmdline.execute("scrapy crawl beijing_windder_spider".split())
