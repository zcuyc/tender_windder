# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from beijing_tender.settings import mysql_host, mysql_port, mysql_user, mysql_passwd, mysql_db

from twisted.enterprise import adbapi
import hashlib


class BeijingTenderPipeline(object):
    def open_spider(self, spider):
        self.dbpool = adbapi.ConnectionPool('pymysql', host=mysql_host, port=mysql_port, user=mysql_user,
                                            passwd=mysql_passwd, db=mysql_db, charset="utf8", use_unicode=True)

    def close_spider(self, spider):
        self.dbpool.close()

    def process_item(self, item, spider):
        self.dbpool.runInteraction(self.insert, item)

    def insert(self, tx, item):
        data = item.insert_sql()
        if data == "tender":
            # sha = hashlib.sha1((item["tender_detail"] + str(item["date_id"])).encode())
            hexdigest_ = hashlib.sha1((item['website']+str(item['date_id'])).encode()).hexdigest()

            insert_sq1_detail_sql = 'insert into ti_tender_detail_detail_day_beijing_yhl(date_id,tender_code,tender_detail) values( "%s","%s","%s")'
            tx.execute(insert_sq1_detail_sql, (item["date_id"], hexdigest_, item["tender_detail"]))

            insert_sql = 'insert into ti_tender_detail_beijing(' \
                         'date_id,' \
                         'tender_code,' \
                         'prjct_name,' \
                         'prjct_code,' \
                         'prjct_desc,' \
                         'prvnce_name,' \
                         'latn_name,' \
                         'county_name,' \
                         'release_time,' \
                         'begin_time,' \
                         'end_time,' \
                         'tender_unit,' \
                         'contactor,' \
                         'contact_phone,' \
                         'purchase_money,' \
                         'agent_unit,' \
                         'agent_contactor,' \
                         'agent_phone,' \
                         'bidder_req,' \
                         'tender_note,' \
                         'open_note,' \
                         'inter_name,' \
                         'website,' \
                         'purchase_money_all,' \
                         'money_num' \
                         ') values (' \
                         '"%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s","%s");'
            item = (item["date_id"],
                    hexdigest_,
                    item["prjct_name"],
                    item["prjct_code"],
                    item["prjct_desc"],
                    item["prvnce_name"],
                    item["latn_name"],
                    item["county_name"],
                    item["release_time"],
                    item["begin_time"],
                    item["end_time"],
                    item["tender_unit"],
                    item["contactor"],
                    item["contact_phone"],
                    item["purchase_money"],
                    item["agent_unit"],
                    item["agent_contactor"],
                    item["agent_phone"],
                    item["bidder_req"],
                    item["tender_note"],
                    item["open_note"],
                    item["inter_name"],
                    item["website"],
                    # hexdigest_
                    item["purchase_money_all"],
                    item["money_num"]
                    )
            tx.execute(insert_sql, item)
        else:
            # sha = hashlib.sha1((item["winbidder_detail"] + str(item["date_id"])).encode())
            hexdigest_ = hashlib.sha1((item['website']+str(item['date_id'])).encode()).hexdigest()

            insert_sq1_detail_sql = 'insert into ti_winbidder_detail_detail_day_beijing(date_id,winbidder_code,winbidder_detail) values( "%s","%s","%s")'
            tx.execute(insert_sq1_detail_sql, (item["date_id"], hexdigest_, item["winbidder_detail"]))

            insert_sql = 'insert into ti_winbidder_detail_day_beijing(' \
                         'date_id,' \
                         'winbidder_code,' \
                         'prjct_name,' \
                         'prjct_code,' \
                         'prvnce_name,' \
                         'latn_name,' \
                         'county_name,' \
                         'release_time,' \
                         'tender_unit,' \
                         'contactor,' \
                         'contact_phone,' \
                         'agent_unit,' \
                         'agent_contactor,' \
                         'agent_phone,' \
                         'winbidder_unit,' \
                         'winbidder_money,' \
                         'begin_time,' \
                         'bid_time,' \
                         'bid_month,' \
                         'inter_name,' \
                         'website,' \
                         'winbidder_unit_all,' \
                         'winbidder_money_all,' \
                         'money_num' \
                         ') values (' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s",' \
                         '"%s","%s","%s","%s","%s","%s","%s","%s",' \
                         '"%s");'
            item = (item["date_id"],
                    hexdigest_,
                    # self.primary_key,
                    item["prjct_name"],
                    item["prjct_code"],

                    item["prvnce_name"],
                    item["latn_name"],
                    item["county_name"],
                    item["release_time"],
                    item["tender_unit"],
                    item["contactor"],
                    item["contact_phone"],
                    item["agent_unit"],
                    item["agent_contactor"],
                    item["agent_phone"],
                    item["winbidder_unit"],
                    item["winbidder_money"],
                    item["begin_time"],
                    item["bid_time"],
                    item["bid_month"],
                    item["inter_name"],
                    item["website"],
                    # hexdigest_
                    item["winbidder_unit_all"],
                    item["winbidder_money_all"],
                    item["money_num"]
                    )
            tx.execute(insert_sql, item)
