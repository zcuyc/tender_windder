# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from beijing_tender.items import BeijingTenderItem


class BeijingTenderSpiderSpider(scrapy.Spider):
    name = 'beijing_tender_spider'
    allowed_domains = ['www.ccgp-beijing.gov.cn']
    start_urls = ['http://www.ccgp-beijing.gov.cn/']

    def start_requests(self):
        for t in range(2):
            if t == 0:
                for i in range(50):
                    if i == 0:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbgg/index.html"
                    else:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbgg/index_{}.html".format(i)
                    # print("start", start_url)
                    yield scrapy.Request(start_url, meta={"t": 0}, callback=self.parse, dont_filter=True)
            else:
                for i in range(3):
                    if i == 0:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbgg/index.html"
                    else:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbgg/index_{}.html".format(i)
                    # print("start", start_url)
                    yield scrapy.Request(start_url, meta={"t": 1}, callback=self.parse, dont_filter=True)

    def parse(self, response):
        hrefs = response.xpath("//ul[@class='xinxi_ul']//a/@href").extract()
        total_datas = list(zip(hrefs, ))
        for e in total_datas:
            if response.meta["t"] == 0:
                url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbgg/" + e[0].split(r"./")[1]
                yield scrapy.Request(url, meta={"t": 0}, callback=self.detail_parse, dont_filter=True)
            else:
                url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbgg/" + e[0].split(r"./")[1]
                yield scrapy.Request(url, meta={"t": 1}, callback=self.detail_parse, dont_filter=True)

    def detail_parse(self, response):
        tendering = BeijingTenderItem()
        if response.meta["t"] == 0:
            tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
            tendering['prjct_name'] = response.css("div > p:contains('项目名称：')::text").extract()[0]
            tendering['prjct_code'] = response.css("div > p:contains('项目编号：')::text").extract()[0]
            tendering['prjct_desc'] = response.css("div > p:contains('欢迎合格的供应商前来投标')::text").extract()[0]
            tendering['prvnce_name'] = "北京市"
            tendering['latn_name'] = "北京市"
            tendering['county_name'] = response.css("div > p:contains('采购单位：') + p + p::text").extract()[0].split("：")[1]
            if "北京市" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京市")[1]
            elif "北京" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京")[1]

            tendering['release_time'] = response.css(".div_hui > .datetime::text").extract()[0].split()[0]
            tendering['begin_time'] = \
                response.css("div > p:contains('时间及地点') + p:contains('预算金额：') + p::text").extract()[0].split("：")[1].split("至")[0].strip()

            if len(response.css("div > p:contains('投标截止时间：')::text").extract()) > 0:
                tendering['end_time'] = response.css("div > p:contains('投标截止时间：')::text").extract()[0]
            else:
                tendering['end_time'] = response.css("div > p:contains('响应文件开启时间:')::text").extract()[0].split(":")[1]

            tendering['tender_unit'] = response.css("div > p:contains('采购单位：')::text").extract()[0].split("：")[1]


            # tendering['contactor'] = \
            #     response.css("div > p:contains('联系方式：')::text").extract()[0].split(",")[0].split("：")[1]
            # tendering['contact_phone'] = response.css("div > p:contains('联系方式：')::text").extract()[0].split(",")[1]

            contactor = response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(contactor)):
                if i == 0:
                    if contactor[0] in "0123456789":
                        tendering['contactor'] = ""
                        tendering['contact_phone'] = contactor
                        break
                else:
                    if contactor[i] in "0123456789":
                        tendering['contactor'] = contactor[0: i - 1]
                        tendering['contact_phone'] = contactor[i:]
                        break
                    tendering['contactor'] = contactor
                    tendering['contact_phone'] = ""

            tendering['purchase_money'] = response.css("div > p:contains('预算金额：')::text").extract()[-1].split("（")[0].split("：")[1]
            if "人民币" in tendering['purchase_money']:
                tendering['purchase_money'] = tendering['purchase_money'].split("人民币")[1]
            if "。" in tendering['purchase_money']:
                tendering['purchase_money'] = tendering['purchase_money'].split("。")[0]
                if "，" in tendering['purchase_money']:
                    tendering['purchase_money'] = tendering['purchase_money'].split("，")[0]
            tendering['agent_unit'] = response.css("div > p:contains('代理机构：')::text").extract()[0].split("：")[1]
            tendering['agent_contactor'] = \
                response.css("div > p:contains('代理机构联系人：')::text").extract()[0].split("，")[0].split("：")[1]
            tendering['agent_phone'] = response.css("div > p:contains('代理机构联系人：')::text").extract()[0].split("，")[1]
            tender_detail = "".join(response.xpath("//*/text()").extract()).replace("\n", "").replace("\t", "")

            if len(response.css("div > p > strong:contains('二、投标人的资格要求：')::text").extract()) > 0:
                tendering['bidder_req'] = "".join(
                    re.split("\n+", tender_detail.split("二、投标人的资格要求：")[1].split("三、招标文件的发售时间及地点等：")[0]))
            else:
                tendering['bidder_req'] = "".join(
                    re.split("\n+", tender_detail.split("二、对供应商资格要求（供应商资格条件）:")[1].split("三、磋商和响应文件时间及地点等")[0]))

            if len(response.css("div > p:contains('投标截止时间：')::text").extract()) > 0:
                tendering['tender_note'] = "".join(
                    re.split("\n+", tender_detail.split("招标文件获取方式：")[1].split("四、投标截止时间：")[0]))
            else:
                tendering['tender_note'] = "".join(
                    re.split("\n+", tender_detail.split("获取磋商文件方式:")[1].split("磋商文件售价")[0]))
                # tendering["tender_note"] = ""

            if len(response.css("div > p:contains('开标时间：')::text").extract()) > 0:
                tendering['open_note'] = response.css("div > p:contains('开标时间：')::text").extract()[0].split()[1] + \
                                         response.css("div > p:contains('六、开标地点：') + p::text").extract()[0]
            else:
                tendering['open_note'] = response.css("div > p:contains('响应文件开启时间:')::text").extract()[0].split(":")[1] + \
                                         response.css("div > p:contains('响应文件开启地点:')::text").extract()[0].split(":")[1]

            tendering['inter_name'] = "北京市政府采购网"
            tendering['website'] = response.url
            tendering['tender_detail'] = tender_detail
            # tendering['crawler_time'] = int(datetime.datetime.now().strftime("%Y%m%d"))

            if len(response.css("div > p:contains('分包编号')::text").extract()) > 0:
                money = response.css("div > p:contains('分包预算金额：')::text").extract()
                money = [i.split("人民币")[1] for i in money]
                tendering["purchase_money_all"] = "@_@".join(money)
                tendering["money_num"] = len(response.css("div > p:contains('分包预算金额：')::text").extract())
            else:
                tendering["purchase_money_all"] = ""
                tendering["money_num"] = 1
        # 区级
        else:
            tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
            tendering['prjct_name'] = response.css("div > p:contains('项目名称：')::text").extract()[0]
            tendering['prjct_code'] = response.css("div > p:contains('项目编号：')::text").extract()[0]
            tendering['prjct_desc'] = response.css("div > p:contains('欢迎合格的供应商前来投标')::text").extract()[0]
            tendering['prvnce_name'] = "北京市"
            tendering['latn_name'] = "北京市"
            tendering['county_name'] = response.css("div > p:contains('采购单位：') + p + p::text").extract()[0].split("：")[
                1]
            if "北京市" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京市")[1]
            elif "北京" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京")[1]

            tendering['release_time'] = response.css(".div_hui > .datetime::text").extract()[0].split()[0]

            if len(response.css("div > p:contains('获取磋商文件时间：')::text").extract()) > 0:
                tendering['begin_time'] = response.css("div > p:contains('获取磋商文件时间：')::text").extract()[0].split("：")[1].split("至")[0].strip()
            else:
                tendering['begin_time'] = \
                    response.css("div > p:contains('时间及地点等：') + p + p::text").extract()[0].split("：")[1].split("至")[0].strip()

            if len(response.css("div > p:contains('投标截止时间：')::text").extract()) > 0:
                tendering['end_time'] = response.css("div > p:contains('投标截止时间：')::text").extract()[0]
            else:
                tendering['end_time'] = response.css("div > p:contains('响应文件开启时间：')::text").extract()[0].split("：")[1]

            tendering['tender_unit'] = response.css("div > p:contains('采购单位：')::text").extract()[0].split("：")[1]

            # if " " in response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1]:
            #     tendering['contactor'] = response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1].split()[0]
            #     tendering['contact_phone'] = response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1].split()[1]
            # else:
            #     tendering['contactor'] = ""
            #     tendering['contact_phone'] = response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1]

            contactor = response.css("div > p:contains('联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(contactor)):
                if i == 0:
                    if contactor[0] in "0123456789":
                        tendering['contactor'] = ""
                        tendering['contact_phone'] = contactor
                        break
                else:
                    if contactor[i] in "0123456789":
                        tendering['contactor'] = contactor[0: i - 1]
                        tendering['contact_phone'] = contactor[i:]
                        break
                    tendering['contactor'] = contactor
                    tendering['contact_phone'] = ""

            tendering['purchase_money'] = \
                response.css("div > p:contains('预算金额：')::text").extract()[0].split("：")[1].split("（")[0]
            if "人民币" in tendering['purchase_money']:
                tendering['purchase_money'] = tendering['purchase_money'].split("人民币")[1]
            if "。" in tendering['purchase_money']:
                tendering['purchase_money'] = tendering['purchase_money'].split("。")[0]
                if "，" in tendering['purchase_money']:
                    tendering['purchase_money'] = tendering['purchase_money'].split("，")[0]
            tendering['agent_unit'] = response.css("div > p:contains('代理机构：')::text").extract()[0].split("：")[1]

            # tendering['agent_contactor'] = response.css("div > p:contains('代理机构联系人：')::text").extract()[0].split("：")[1]
            # tendering['agent_phone'] = response.css("div > p:contains('代理机构联系人：')::text").extract()[0].split("：")[1]
            agent = response.css("div > p:contains('代理机构联系人：')::text").extract()[0].split("：")[1]
            for i in range(len(agent)):
                if i == 0:
                    if agent[0] in "0123456789":
                        tendering['agent_contactor'] = ""
                        tendering['agent_phone'] = agent
                        break
                else:
                    if agent[i] in "0123456789":
                        tendering['agent_contactor'] = agent[0: i - 1]
                        tendering['agent_phone'] = agent[i:]
                        break
                    tendering['agent_contactor'] = agent
                    tendering['agent_phone'] = ""

            tender_detail = "".join(response.xpath("//*/text()").extract()).replace("\n", "").replace("\t", "")

            if len(response.css("div > p > strong:contains('二、投标人的资格要求：')::text").extract()) > 0:
                tendering['bidder_req'] = "".join(
                    re.split("\n+", tender_detail.split("二、投标人的资格要求：")[1].split("三、招标文件的发售时间及地点等：")[0]))
            else:
                tendering['bidder_req'] = "".join(
                    re.split("\n+", tender_detail.split("二、对供应商资格要求（供应商资格条件）:")[1].split("三、磋商和响应文件时间及地点等")[0]))

            if len(response.css("div > p:contains('投标截止时间：')::text").extract()) > 0:
                tendering['tender_note'] = "".join(
                    re.split("\n+", tender_detail.split("招标文件获取方式：")[1].split("四、投标截止时间：")[0]))
            else:
                tendering['tender_note'] = "".join(
                    re.split("\n+", tender_detail.split("获取磋商文件方式：")[1].split("磋商文件售价")[0]))
                # tendering["tender_note"] = ""

            if len(response.css("div > p:contains('开标时间：')::text").extract()) > 0:
                tendering['open_note'] = response.css("div > p:contains('开标时间：')::text").extract()[0] + \
                                         response.css("div > p:contains('开标地点：') + p::text").extract()[0]
            else:
                tendering['open_note'] = response.css("div > p:contains('响应文件开启时间：')::text").extract()[0].split("：")[1] + \
                                         response.css("div > p:contains('响应文件开启地点：')::text").extract()[0].split("：")[1]

            tendering['inter_name'] = "北京市政府采购网"
            tendering['website'] = response.url
            tendering['tender_detail'] = tender_detail
            # tendering['crawler_time'] = int(datetime.datetime.now().strftime("%Y%m%d"))

            if len(response.css("div > p:contains('分包编号')::text").extract()) > 0:
                tendering["purchase_money_all"] = "@_@".join(
                    response.css("div > p:contains('分包预算金额：')::text").extract())
                tendering["money_num"] = len(response.css("div > p:contains('分包预算金额：')::text").extract())
            else:
                tendering["purchase_money_all"] = ""
                tendering["money_num"] = 1
        yield tendering
        # print(tendering['tender_note'])
