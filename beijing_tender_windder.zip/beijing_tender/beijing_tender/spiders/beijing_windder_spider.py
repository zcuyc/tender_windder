# -*- coding: utf-8 -*-
import scrapy
import datetime
import re

from beijing_tender.items import BeijingWindderItem


class BeijingWindderSpiderSpider(scrapy.Spider):
    name = 'beijing_windder_spider'
    allowed_domains = ['www.ccgp-beijing.gov.cn']
    start_urls = ['http://www.ccgp-beijing.gov.cn/']

    def start_requests(self):
        for t in range(2):
            if t == 0:
                for i in range(100):
                    if i == 0:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbjggg/index.html"
                    else:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbjggg/index_{}.html".format(i)
                    # print("start", start_url)
                    yield scrapy.Request(start_url, meta={"t": 0}, callback=self.parse, dont_filter=True)
            else:
                for i in range(3):
                    if i == 0:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbjggg/index.html"
                    else:
                        start_url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbjggg/index_{}.html".format(i)
                    # print("start", start_url)
                    yield scrapy.Request(start_url, meta={"t": 1}, callback=self.parse, dont_filter=True)

    def parse(self, response):
        hrefs = response.xpath("//ul[@class='xinxi_ul']//a/@href").extract()
        total_datas = list(zip(hrefs, ))
        for e in total_datas:
            if response.meta["t"] == 0:
                url = "http://www.ccgp-beijing.gov.cn/xxgg/sjzfcggg/sjzbjggg/" + e[0].split(r"./")[1]
                yield scrapy.Request(url, meta={"t": 0}, callback=self.detail_parse, dont_filter=True)
            else:
                url = "http://www.ccgp-beijing.gov.cn/xxgg/qjzfcggg/qjzbjggg/" + e[0].split(r"./")[1]
                # print("url", url)
                yield scrapy.Request(url, meta={"t": 1}, callback=self.detail_parse, dont_filter=True)

    def detail_parse(self, response):
        tendering = BeijingWindderItem()
        if response.meta["t"] == 0:
            tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
            tendering['prjct_name'] = response.css("div > p:contains('项目名称：')::text").extract()[0].split("：")[1]
            tendering['prjct_code'] = response.css("div > p:contains('项目编号：')::text").extract()[1].split("：")[1]
            tendering['prvnce_name'] = "北京市"
            tendering['latn_name'] = "北京市"
            tendering['county_name'] = response.css("div > p:contains('采购单位地址：')::text").extract()[0].split("：")[1]
            if "北京市" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京市")[1]
            elif "北京" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京")[1]

            tendering['release_time'] = response.css("div > p:contains('本项目招标公告日期：')::text").extract()[0].split("：")[1]
            tendering['tender_unit'] = response.css("div > p:contains('采购单位名称：')::text").extract()[0].split("：")[1]

            # tendering['contactor'] = response.css("div > p:contains('采购单位联系方式：')::text").extract()[0].split("：")[1]
            contactor = response.css("div > p:contains('采购单位联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(contactor)):
                if i == 0:
                    if contactor[0] in "0123456789":
                        tendering['contactor'] = ""
                        tendering['contact_phone'] = contactor
                        break
                else:
                    if contactor[i] in "0123456789":
                        tendering['contactor'] = contactor[0: i - 1]
                        tendering['contact_phone'] = contactor[i:]
                        break
                    tendering['contactor'] = contactor
                    tendering['contact_phone'] = ""

            tendering['agent_unit'] = response.css("div > p:contains('采购代理机构全称：')::text").extract()[0].split("：")[1]

            # tendering['agent_contactor'] = response.css("div > p:contains('采购代理机构联系方式：')::text").extract()[0].split("：")[1]
            agent = response.css("div > p:contains('采购代理机构联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(agent)):
                if i == 0:
                    if agent[0] in "0123456789":
                        tendering['agent_contactor'] = ""
                        tendering['agent_phone'] = agent
                        break
                else:
                    if agent[i] in "0123456789":
                        tendering['agent_contactor'] = agent[0: i - 1]
                        tendering['agent_phone'] = agent[i:]
                        break
                    tendering['agent_contactor'] = agent
                    tendering['agent_phone'] = ""

            winbidder_unit = response.css("div > p:contains('中标成交供应商名称：')::text").extract()
            winbidder_unit = [i.split("：")[1] for i in winbidder_unit]
            tendering['winbidder_unit'] = "@_@".join(winbidder_unit)

            tendering['winbidder_money'] = \
            response.css("div > p:contains('总中标成交金额：')::text").extract()[0].split("：")[1].split("（")[0]
            tendering['begin_time'] = response.css("div > p:contains('本项目招标公告日期：')::text").extract()[0].split("：")[1]
            tendering['bid_time'] = response.css("div > p:contains('中标成交日期：')::text").extract()[0].split("：")[1]
            tendering['bid_month'] = response.css("div > p:contains('中标成交日期：')::text").extract()[0].split("：")[1]
            tendering['inter_name'] = "北京市政府采购网"
            tendering['website'] = response.url
            tendering['winbidder_detail'] = "".join(response.xpath("//*/text()").extract()).replace("\n", "").replace(
                "\t", "")

            if len(response.css("div > p:contains('中标成交供应商名称：')::text").extract()) > 1:

                winbidder_unit_all = response.css("div > p:contains('中标成交供应商名称：')::text").extract()
                winbidder_unit_all = [i.split("：")[1] for i in winbidder_unit_all]
                tendering["winbidder_unit_all"] = "@_@".join(winbidder_unit_all)

                winbidder_money_all = response.css("div > p:contains('中标金额：')::text").extract()
                winbidder_money_all = [i.split("：")[1] for i in winbidder_money_all]
                tendering["winbidder_money_all"] = "@_@".join(winbidder_money_all)

                tendering["money_num"] = len(response.css("div > p:contains('中标成交供应商名称：')::text").extract())
            else:
                tendering["winbidder_unit_all"] = ""
                tendering["winbidder_money_all"] = ""
                tendering["money_num"] = 1
        # 区级
        else:
            tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
            tendering['prjct_name'] = response.css("div > p:contains('项目名称：')::text").extract()[0].split("：")[1]
            tendering['prjct_code'] = response.css("div > p:contains('项目编号：')::text").extract()[1].split("：")[1]
            tendering['prvnce_name'] = "北京市"
            tendering['latn_name'] = "北京市"
            if "北京市" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京市")[1]
            elif "北京" in tendering['county_name']:
                tendering['county_name'] = tendering['county_name'].split("北京")[1]

            tendering['county_name'] = response.css("div > p:contains('采购单位地址：')::text").extract()[0].split("：")[1]

            tendering['release_time'] = response.css("div > p:contains('招标公告日期：')::text").extract()[0].split("：")[1]
            tendering['tender_unit'] = response.css("div > p:contains('采购单位名称：')::text").extract()[0].split("：")[1]

            # tendering['contactor'] = response.css("div > p:contains('采购单位联系方式：')::text").extract()[0].split("：")[1]
            contactor = response.css("div > p:contains('采购单位联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(contactor)):
                if i == 0:
                    if contactor[0] in "0123456789":
                        tendering['contactor'] = ""
                        tendering['contact_phone'] = contactor
                        break
                else:
                    if contactor[i] in "0123456789":
                        tendering['contactor'] = contactor[0: i - 1]
                        tendering['contact_phone'] = contactor[i:]
                        break
                    tendering['contactor'] = contactor
                    tendering['contact_phone'] = ""

            tendering['agent_unit'] = response.css("div > p:contains('采购代理机构全称：')::text").extract()[0].split("：")[1]

            # tendering['agent_contactor'] = response.css("div > p:contains('采购代理机构联系方式：')::text").extract()[0].split("：")[1]
            agent = response.css("div > p:contains('采购代理机构联系方式：')::text").extract()[0].split("：")[1]
            for i in range(len(agent)):
                if i == 0:
                    if agent[0] in "0123456789":
                        tendering['agent_contactor'] = ""
                        tendering['agent_phone'] = agent
                        break
                else:
                    if agent[i] in "0123456789":
                        tendering['agent_contactor'] = agent[0: i - 1]
                        tendering['agent_phone'] = agent[i:]
                        break
                    tendering['agent_contactor'] = agent
                    tendering['agent_phone'] = ""

            if len(response.css("div > p:contains('中标单位名称：')::text").extract()) > 0:
                tendering['winbidder_unit'] = "".join(response.css("div > p:contains('中标单位名称：')::text").extract())
            elif len(response.css("tr:contains('中标供应商名称')::text").extract()) > 0:
                tendering['winbidder_unit'] = response.css("tr:contains('中标供应商名称') + tr > td + td::text").extract()[0]
            elif len(response.css("div > p:contains('成交供应商名称：')::text").extract()) > 0:
                tendering['winbidder_unit'] = "".join(response.css("div > p:contains('成交供应商名称：')::text").extract())
            elif len(response.css("div > p:contains('中标人：')::text").extract()) > 0:
                tendering['winbidder_unit'] = "".join(response.css("div > p:contains('中标人：')::text").extract())
            elif len(response.css("tr:contains('成交供应商名称')::text").extract()) > 0:
                tendering['winbidder_unit'] = response.css("tr:contains('成交供应商名称') + tr > td + td::text").extract()[0]
            else:
                tendering['winbidder_unit'] = ""

            if len(response.css("div > p:contains('总中标金额：')::text").extract()) > 0:
                tendering['winbidder_money'] = response.css("div > p:contains('总中标金额：')::text").extract()[0].split("：")[1].split("（")[0]
            else:
                tendering['winbidder_money'] = response.css("div > p:contains('总成交金额：')::text").extract()[0].split("：")[1].split("（")[0]

            tendering['begin_time'] = response.css("div > p:contains('招标公告日期：')::text").extract()[0].split("：")[1]

            if len(response.css("div > p:contains('中标日期：')::text").extract()) > 0:
                tendering['bid_time'] = response.css("div > p:contains('中标日期：')::text").extract()[0].split("：")[1]
                tendering['bid_month'] = response.css("div > p:contains('中标日期：')::text").extract()[0].split("：")[1]
            else:
                tendering['bid_time'] = response.css("div > p:contains('成交日期：')::text").extract()[0].split("：")[1]
                tendering['bid_month'] = response.css("div > p:contains('成交日期：')::text").extract()[0].split("：")[1]

            tendering['inter_name'] = "北京市政府采购网"
            tendering['website'] = response.url
            tendering['winbidder_detail'] = "".join(response.xpath("//*/text()").extract()).replace("\n", "").replace(
                "\t", "")

            # if len(response.css("div > p:contains('中标成交供应商名称：')::text").extract()) > 1:
            #     tendering["winbidder_unit_all"] = "@_@".join(
            #         response.css("div > p:contains('中标成交供应商名称：')::text").extract())
            #     tendering["winbidder_money_all"] = "@_@".join(response.css("div > p:contains('中标金额：')::text").extract())
            #     tendering["money_num"] = len(response.css("div > p:contains('中标成交供应商名称：')::text").extract())
            # else:
            tendering["winbidder_unit_all"] = ""
            tendering["winbidder_money_all"] = ""
            tendering["money_num"] = 1
        yield tendering
