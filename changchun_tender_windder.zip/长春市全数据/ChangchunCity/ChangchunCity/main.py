from scrapy import cmdline
v = int(input('1 or 2:'))
if v == 1:
    cmdline.execute("scrapy crawl changchun_tender".split())
elif v == 2:
    cmdline.execute("scrapy crawl changchun_winbidder".split())
else:
    print('输入错误')
