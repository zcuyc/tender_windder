# -*- coding: utf-8 -*-
import datetime
import json
import re
import scrapy
from ChangchunCity.items import ChangchuncitytenderItem


class ChangchunTenderSpider(scrapy.Spider):
    name = 'changchun_tender'
    allowed_domains = ['www.ccggzy.gov.cn']
    start_urls = ['http://www.ccggzy.gov.cn']
    j=0

    def start_requests(self):
        # for page in range(2,11):
        #     base_url = 'http://www.ccggzy.gov.cn/ccggzy/getxxgkAction.action?' \
        #                'cmd=getCityZfcgInfo&pageIndex={}&pageSize=16&' \
        #                'siteGuid=7eb5f7f1-9041-43ad-8e13-8fcb82ea831a&categorynum=002001001&xiaqucode=220101&jyfl=%E5%85%A8%E9%83%A8'.format(page)
        page =15
        con = 16 * page
        base_url = 'http://www.ccggzy.gov.cn/ccggzy/getxxgkAction.action?' \
                   'cmd=getCityZfcgInfo&pageIndex=&pageSize={}&' \
                   'siteGuid=7eb5f7f1-9041-43ad-8e13-8fcb82ea831a&categorynum=002001001&xiaqucode=220101&jyfl=%E5%85%A8%E9%83%A8'.format(con)
        j=0
        yield scrapy.Request(base_url, callback=self.parse, dont_filter=True)


    def parse(self, response):
        s = json.loads(response.text)
        s1 = json.loads(s['custom'])
        print(s1)
        for i in s1["Table"]:

            url = 'http://www.ccggzy.gov.cn' + i['href']
            info=i['infodate']
            yield scrapy.Request(url, callback=self.detail_parse, meta={'info':info,'url':url},dont_filter=True)


    def detail_parse(self, response):
        tendering = ChangchuncitytenderItem()
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))

        ###项目名称
        tendering['prjct_name'] = response.xpath("//h3[@class='ewb-text-tt']/text()").extract()[0][:-4]
        print('项目名称',tendering['prjct_name'])

        ###项目编号
        if response.xpath("//p/span[@lang='EN-US'][3]/text()").extract():
            tendering['prjct_code'] = response.xpath("//p/span[@lang='EN-US'][3]/text()").extract()[0]
        elif response.xpath("//div[@class='ewb-text-content ewb-row']/p/span/span/text()").extract():
            tendering['prjct_code']=response.xpath("//div[@class='ewb-text-content ewb-row']/p/span/span/text()").extract()[0]
        elif response.xpath("//p[@class='MsoNormal']/span/text()").extract():
            text=response.xpath("//p[@class='MsoNormal']/span/text()").extract()
            try:
                s=int(text[1])
                tendering['prjct_code'] = text[0] + text[1]
            except Exception as e:
                tendering['prjct_code']=text[0]
            print('项目编号',tendering['prjct_code'])

        else:

            print(",wo还是没有")
            return "11"

        ###项目概述
        tendering['prjct_desc']='*******************'

        ###所属省份
        tendering['prvnce_name'] ='吉林省'
        tendering['latn_name']='长春市'

        ##所属区县 标准地址
        s1=response.xpath("//div[@id='print']/p/span[contains(text(),'地址')]/text()")
        s2=response.xpath('//*[@id="print"]/div/p[contains(span/text(),"地址")]')
        s3=response.xpath("//*[@id='print']/p[40]")
        if s2:
            tendering['county_name']=s2[0] .xpath("string(.)").extract_first().replace("\n","").replace("\t","").replace(" ","")
        elif s1:
            tendering['county_name'] = s1.extract_first().replace("\n","").replace("\t","").replace(" ","")
        elif s3:
            tendering['county_name'] = s3[0].xpath("string(.)").extract_first().replace("\n","").replace("\t","").replace(" ","")
        else:
            print('--------------------------->>>>>>>>>>>>没有标准地址')
        print('所属区县 标准地址',tendering['county_name'])

        ##发布时间
        tendering['release_time']=response.meta['info']
        print('发布时间',tendering['release_time'])

        ##开始时间
        if response.xpath('//*[@id="print"]/div/p[contains(span/text(),"开标时间")]/span[contains(text(),"2019")]').extract():
            p=response.xpath('//*[@id="print"]/div/p[contains(span/text(),"开标时间")]/span[contains(text(),"2019")]/text()').extract()[0]
            res=re.compile(r'201.*?日').findall(p)[0].replace('年','-').replace('月','-').replace('日','')
            tendering['begin_time'] = res
        else:
            tendering['begin_time'] = response.meta['info']
        print('开始时间',tendering['begin_time'])

        #截止时间
        if response.xpath('//*[@id="print"]/p[contains(span/text(),"5.1")]').extract():
            # print('-------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
            p=''.join(response.xpath('//*[@id="print"]/p[contains(span/text(),"5.1")]//text()').extract())
            res = re.compile(r'201.*?日').findall(p)[0].replace('年', '-').replace('月', '-').replace('日', '').replace(' ', '')
            tendering['end_time'] = res
        elif response.xpath('//*[@id="print"]/div/p[contains(span//text(),"1.")]//text()').extract():
            p=''.join(response.xpath('//*[@id="print"]/div/p[contains(span//text(),"1.")]//text()').extract())
            try:
                res = re.compile(r'投标文件.*(201.*?日)').findall(p)[0].replace('年', '-').replace('月', '-').replace('日', '').replace(' ','')
                tendering['end_time'] = res
            except Exception as e:
                res = re.compile(r'响应文件.*(201.*?日)').findall(p)[0].replace('年', '-').replace('月', '-').replace('日', '').replace(' ', '')
                tendering['end_time']=res
        print('截止时间',tendering['end_time'])



        try:
            # 采购联系人
            span1 = response.xpath('//div/p/span/text()').extract()
            # print(span1)
            res1 = list(filter(lambda ele: '联系人：' in ele, span1))[0]
            index0=span1.index(res1)
            tendering['contactor'] = span1[index0 + 1]
            # 联系电话
            res1 = list(filter(lambda ele: '联系电话：' in ele, span1))[0]
            index1 = span1.index(res1)
            tendering['contact_phone'] = span1[index1 + 1]
            if '地址' in tendering['contact_phone']:
                # print('OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmO')
                span_test = response.xpath('//div/p/span//text()').extract()
                # print(span_test)
                res1 = list(filter(lambda ele: '联系人：' in ele, span_test))[0]
                index0 = span_test.index(res1)
                if res1=='联系人：':
                    tendering['contactor'] = span_test[index0 + 1]
                else:
                    tendering['contactor'] = span_test[index0]

                res6 = list(filter(lambda ele: '联系电话：' in ele, span_test))[0]
                index1 = span_test.index(res6)
                phone=''
                for ind in range(index1+1,index1+10):
                    if '地址' in span_test[ind]:
                        break
                    phone=phone+span_test[ind]
                tendering['contact_phone']=phone
            print('采购联系人:', tendering['contactor'])
            print('联系电话:', tendering['contact_phone'])



            # 采购单位
            res2 = list(filter(lambda ele: '购人：' in ele, span1))[0]
            index2 = span1.index(res2)
            tendering['tender_unit'] = span1[index2 + 1]
            print('采购单位:', tendering['tender_unit'])

            #采购代理单位
            res3 = list(filter(lambda ele: '代理机构' in ele, span1))[0]
            if res3:
                tendering['agent_unit']=res3
                print('采购代理单位:', tendering['agent_unit'])
            else:
                print('采购代理单位 无')

            #代理单位联系人
            res4 = list(filter(lambda ele: '采购文件咨询人' in ele or '招标文件咨询人' in ele, span1))
            if res4:
                tendering['agent_contactor'] = res4[0]
                print('代理单位联系人:', tendering['agent_contactor'])
                # 代理单位联系人电话
                index4 = span1.index(res4[0])
                tendering['agent_phone'] = span1[index4 + 3]
                if tendering['agent_phone']=='         ':
                    # print('dddddd=====xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
                    tendering['agent_phone']= span1[index4 + 2].split('：')[-1]

                print('代理单位联系人电话:', tendering['agent_phone'])

            elif list(filter(lambda ele: '联系人' in ele, span1)):
                tendering['agent_contactor'] = list(filter(lambda ele: '联系人' in ele, span1))[0]
                print('代理单位联系人:', tendering['agent_contactor'])
                index5 = span1.index(tendering['agent_contactor'])
                tendering['agent_phone'] = span1[index5 + 1]
                print('代理单位联系人电话:', tendering['agent_phone'])
            else:
                print('代理单位联系人  无')
        except Exception as e:
            print('-----e  >')
            tendering['contactor'] =''.join(response.xpath('//*[@id="print"]/p[41]/span[1]//text()').extract()).replace(' ', '')
            tendering['contact_phone'] =''.join(response.xpath('//*[@id="print"]/p[42]/span[3]//text()').extract()).replace(' ', '')
            tendering['tender_unit'] =''.join(response.xpath('//*[@id="print"]/p[39]/span[1]//text()').extract()).replace(' ', '')
            tendering['agent_contactor'] =''.join(response.xpath('//*[@id="print"]/p[45]//text()').extract()).replace(' ', '')
            tendering['agent_unit'] =''.join(response.xpath( '//*[@id="print"]/p[43]//text()').extract()).replace(' ', '')
            tendering['agent_phone'] =''.join(response.xpath( '//*[@id="print"]/p[46]/span[1]//text()').extract()).replace(' ', '')
            print(tendering['contactor'],tendering['contact_phone'],tendering['tender_unit'],tendering['agent_contactor'],tendering['agent_unit'],tendering['agent_phone'],sep='\r\n')

        finally:

            if '[社会代理]' in tendering['prjct_name']:
                # print( 'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')
                print('--->w我是  社会代理')
            else:
                #供应商资格条件
                if '[采购公告]' in tendering['prjct_name']:
                    print('MMMMMMMMMMMM')
                span_3=response.xpath('//div/p/span/text()').extract()
                # print(span_3)
                eg1=list(filter(lambda ele: '供应商资格条件' in ele or '投标人资格条件' in ele ,span_3))[0]
                index_eg1=span_3.index(eg1)
                eg2=list(filter(lambda ele: '政府采购政策' in ele,span_3))[0]
                index_eg2=span_3.index(eg2)
                list_biddder_req=span_3[index_eg1+1:index_eg2]
                tendering['bidder_req']=''.join(list_biddder_req).replace("\n","").replace("\t","").replace(" ","")
                print('供应商资格条件:',tendering['bidder_req'])

                # 文件获取
                eg1 = list(filter(lambda ele: '文件获取' in ele or '四、' in ele, span_3))[0]
                index_eg1 = span_3.index(eg1)
                eg2 = list(filter(lambda ele: '现场考察' in ele or '五、' in ele, span_3))[0]
                index_eg2 = span_3.index(eg2)
                list_tender_note = span_3[index_eg1 + 1:index_eg2]
                tendering['tender_note'] = ''.join(list_tender_note).replace("\n", "").replace("\t", "").replace(" ", "")
                print('文件获取:', tendering['tender_note'])

                #开标说明时间与地点

                eg1 = list(filter(lambda ele: '投标文件提交' in ele or '响应文件提交' in ele, span_3))[0]
                index_eg1 = span_3.index(eg1)
                eg2 = list(filter(lambda ele: '响应文件开启' in ele or '七、' in ele, span_3))[0]
                index_eg2 = span_3.index(eg2)
                list_open_note = span_3[index_eg1 + 1:index_eg2]
                tendering['open_note'] = ''.join(list_open_note).replace("\n", "").replace("\t", "").replace(" ", "")
                print('开标说明时间与地点:', tendering['open_note'])

                #项目分包数量:
                eg1 = list(filter(lambda ele: '项目分包数量' in ele, span_3))[0]
                index_eg1 = span_3.index(eg1)
                num= int(span_3[index_eg1 + 1][0][0])
                tendering['money_num']=str(num)
                print('项目分包数量:',num)
                if num==1:
                    money=''.join(response.xpath("//table//tr[2]/td[5]//text()").extract()).replace("\n", "").replace("\t", "").replace(" ", "")+'元'
                    tendering["purchase_money"]=money
                    tendering["purchase_money_all"] = ''

                    print('预算金额',tendering["purchase_money"])
                else:
                    money=''.join(response.xpath("//table//tr[2]/td[5]//text()").extract()).replace("\n", "").replace("\t", "").replace(" ", "")+'元'
                    for k in range(3,num+2):
                        money=money+'@_@'+ ''.join(response.xpath("//table//tr[{}]/td[5]//text()".format(k)).extract()).replace("\n", "").replace("\t", "").replace(" ", "")+'元'
                    tendering["purchase_money_all"] = money
                    tendering["purchase_money"]=''
                    print('预算金额', tendering["purchase_money_all"])

                #项目概述
                tendering['prjct_desc']=''
            #
            tendering['inter_name']='长春公共资源交易中心'

            #
            tendering['website'] = response.meta['url']

            #

            tendering['tender_detail']=''.join(response.xpath('/html/body/div[@class="ewb-mainpart"]//text()').extract())
            tendering['etl_time']=tendering['date_id']
            tendering['status'] = ''


            #字段清洗
            tendering['county_name'] =tendering['county_name'].split('：')[-1].split('市')[-1]
            tendering['agent_unit'] = tendering['agent_unit'].split('：')[-1]
            tendering['agent_contactor'] = tendering['agent_contactor'].split('：')[-1].split(':')[-1]
            tendering['tender_detail']=tendering['tender_detail'].split('正文')[-1].split('温馨提示')[0].split('关联采购公告')[0]
            # print('---------------------------------------------------------------------------->>>')
            # print(tendering['tender_detail'])

        self.j+=1
        print('------->>>',self.j)




        yield tendering
