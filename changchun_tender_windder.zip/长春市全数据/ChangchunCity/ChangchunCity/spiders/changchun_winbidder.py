# -*- coding: utf-8 -*-
import datetime
import json
import re

import scrapy

from ChangchunCity.items import ChangchuncitywinbidderItem


class ChangchunWinbidderSpider(scrapy.Spider):
    name = 'changchun_winbidder'
    allowed_domains = ['www.ccggzy.gov.cn']
    start_urls = ['http://www.ccggzy.gov.cn']
    j=0

    def start_requests(self):

        page =71
        con = 16 * page
        base_url = 'http://www.ccggzy.gov.cn/ccggzy/getxxgkAction.action?' \
                   'cmd=getCityZfcgInfo&pageIndex=1&pageSize={}&siteGuid=7eb5f7f1-9041-43ad-8e13-8fcb82ea831a&' \
                   'categorynum=002001004&xiaqucode=220101&jyfl=%E5%85%A8%E9%83%A8'.format(con)
        j = 0
        yield scrapy.Request(base_url, callback=self.parse, dont_filter=True)
    def parse(self, response):

        s = json.loads(response.text)
        s1 = json.loads(s['custom'])
        for i in s1["Table"]:
            url = 'http://www.ccggzy.gov.cn' + i['href']
            yield scrapy.Request(url, callback=self.detail_parse,meta={'url':url},dont_filter=True)

    def detail_parse(self, response):
        # title=response.xpath("//div[@class='ewb-text-box']//h3/text()").extract()[0]
        # print(title)
        winbiddering = ChangchuncitywinbidderItem()
        winbiddering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))

        #项目名称：
        winbiddering['prjct_name'] = response.xpath("//h3[@class='ewb-text-tt']/text()").extract()[0][:-4]
        if '废标' in winbiddering['prjct_name']:
            print('废标公告舍去')
            return None
        print(winbiddering['prjct_name'])

        #模板讨论
        if 1:
            pass
            div_text=(''.join(response.xpath('//*[@class="ewb-text-box"]//text()').extract()))
            chars='#'.join(div_text.split())
            print(chars)
            if '废标' in chars:
                print('------------------------->>废标')
                return None
            elif '终止采购' in chars:
                print('------------------------->>废标')
                return None
            else:
                pass

            #项目标号：
            if re.compile(r'项目编号：#.+?#').findall(chars):
                con_code = (re.compile(r'项目编号：#.+?#').findall(chars)[0]).replace('#', '').split('：')[ -1]
            elif re.compile(r'项目编号.+?#').findall(chars):
                con_code = (re.compile(r'项目编号.+?#').findall(chars)[0]).replace('#', '').split('：')[-1]
            else:
                print('------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>prjct_code')
                con_code=''
            winbiddering['prjct_code']=con_code
            print(winbiddering['prjct_code'])

            #中标省份
            winbiddering['prvnce_name']='吉林省'
            winbiddering['latn_name'] = '长春市'

            #招标县 标准地址
            if re.compile(r'采购人.+?联系').findall(chars):
                res99=re.compile(r'采购人.+?联系').findall(chars)[0]
                con_add=(re.compile(r'(地址.+?)联系').findall(res99)[0]).replace('#','').split('：')[-1].split(':')[-1]
            else:
                print('------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>county_name')
                con_add=''
            winbiddering['county_name']=con_add.split('长春市')[-1]
            print(winbiddering['county_name'])

            #采购公告发布时间
            if re.compile(r'采购公告日期.+?日').findall(chars):
                con_time1 = (re.compile(r'采购公告日期.+?日').findall(chars)[0]).replace('#', '').split('：')[-1].split(':')[-1]
                con_time1=con_time1.replace('年','-').replace('月','-').replace('日','')
            else:
                # print('------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>release_time')
                con_time1 = ''
            winbiddering['begin_time']=con_time1
            print(winbiddering['begin_time'])

            #招标单位或个人
            if (re.compile(r'采购人.+?联系.+?\d.*?#').findall(chars)):
                c=(re.compile(r'采购人.+?联系.+?\d.*?#').findall(chars)[0])
                winbiddering['tender_unit'] = re.compile(r'(采购人.*?)地址').findall(c)[0].replace('#', '').split('：')[-1].split(':')[-1]
                try:
                    winbiddering['contactor'] = re.compile(r'(联系人.*?)联系').findall(c)[0].replace('#', '').split('：')[-1].split(':')[-1]
                except:
                    winbiddering['contactor'] =''

                winbiddering['contact_phone'] = re.compile(r'(联系.*?\d.*)').findall(c)[0].replace('#', '').split('：')[-1].split(':')[-1]
            else:
                print('------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>tender_unit,contactor,contact_phone')
            print(winbiddering['tender_unit'],winbiddering['contactor'],winbiddering['contact_phone'],sep='\n')

            # 招标  代理单位和联系人
            if re.compile(r'采购中心联系.*?地址').findall(chars):
                c = re.compile(r'(一、政府集中.*?)二、').findall(chars)[0].replace('#', '').split('：')[-1].split(':')[-1]
                c1 = re.compile(r'(采购中心联系.*?)联系').findall(chars)[0].replace('#', '').split('：')[-1].split(':')[-1]
                c2 = re.compile(r'(联系电话.*?\d.*?#)').findall(chars)[0].replace('#', '').split('：')[-1].split(':')[-1].split('；')[0]
                print(c, c1, c2, sep='\n')
            else:
                try:
                    c = re.compile(r'(政府集中采购机构：.*?)地址').findall(chars)[0].replace('#', '').split('：')[-1].split(':')[-1]
                    c1 = re.compile(r'(联系人.*?)联系').findall(chars)[0].replace('#', ',').split('：')[-1].split(':')[-1][:-1]
                    c2 = re.compile(r'(联系电话.*?\d*?#).*?二、').findall(chars)[0].replace('#', '').split('：')[-1].split(':')[-1].split('；')[0]
                    print(c, c1, c2, sep='\n')
                except:
                    return None
            winbiddering['agent_unit']=c
            winbiddering['agent_contactor'] =c1

            winbiddering['agent_phone'] =c2


            #中标单位/中标供应商
            if response.xpath('//*[@id="print"]/div/table'):
                res1,res2='',''
                k=0
                per=''.join((''.join(response.xpath('//div/table/tbody/tr[1]/td[4]//text()').extract())).split())
                per_0=re.compile('.*?（(.*?)）').findall(per)
                if per_0==[]:
                    per_1=''
                else:
                    per_1=per_0[0]

                for i in range(2,20):
                    k=i
                    if response.xpath('//div/table/tbody/tr[{}]'.format(i)):
                        res1=res1+''.join((''.join(response.xpath('//div/table/tbody/tr[{}]/td[3]//text()'.format(i)).extract())).split())+'@_@'
                        v=''.join((''.join(response.xpath('//div/table/tbody/tr[{}]/td[4]//text()'.format(i)).extract())).split())
                        v_0=re.compile('\d').findall(v)
                        if v_0==[]:
                            res2 = res2 + v + '@_@'
                        else:
                            res2=res2+v+per_1+'@_@'
                    else:
                        break
                if k>3:
                    winbiddering['money_num'] = str(k-2)
                    winbiddering['status'] = ''
                    winbiddering['winbidder_unit'] = ''
                    winbiddering['winbidder_money'] = ''
                    winbiddering['winbidder_unit_all'] =res1[:-3]
                    winbiddering['winbidder_money_all'] = res2[:-3]

                else:
                    winbiddering['money_num'] = ''
                    winbiddering['status']=''
                    winbiddering['winbidder_unit'] = res1[:-3]
                    winbiddering['winbidder_money'] = res2[:-3]
                    winbiddering['winbidder_unit_all'] = ''
                    winbiddering['winbidder_money_all'] = ''
                    print('中标单位/中标供应商:',winbiddering['winbidder_unit'],winbiddering['winbidder_money'],winbiddering['winbidder_unit_all'],winbiddering['winbidder_money_all'],sep='\n')
            else:
                return None

            winbiddering['bid_time'] = ''
            winbiddering['bid_month'] = ''
            winbiddering['inter_name'] = '长春市公共资源交易网'
            winbiddering['website'] =response.meta['url']
            winbiddering['winbidder_detail']=''.join(response.xpath('/html/body/div[@class="ewb-mainpart"]//text()').extract())
            winbiddering['etl_time']=winbiddering['date_id']
            winbiddering['money_num']=winbiddering['money_num'] if winbiddering['money_num'] else '1'



            time_chars=''.join(response.xpath('//div//text()').extract()).strip()
            res_0=re.compile(r'信息时间：(.*?)阅读次数').findall(time_chars)[0]
            print('------------------------------->>>>')
            winbiddering['release_time']=res_0
            winbiddering['winbidder_detail'] = winbiddering['winbidder_detail'].split('正文')[-1].split('温馨提示')[0].split('关联采购公告')[0]



        self.j+=1
        print('pro_num--->>',self.j)
        yield winbiddering
