# -*- coding: utf-8 -*-
import datetime
import json
import re
import time

import scrapy

from guiyang_tender_windder.items import GuiyangTenderItem


class GuiyangTenderSpiderSpider(scrapy.Spider):
    name = 'guiyang_tender_spider'
    allowed_domains = ['www.gyggzy.cn/c14512/index.html']
    start_urls = ['http://www.gyggzy.cn/c14512/index.html/']

    def start_requests(self):
        start_urls = ['http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14512&pageno={}',
                      'http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14513&pageno={}',
                      'http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14514&pageno={}']
        for pag in start_urls:
            if "14512" in pag:
                for i in range(0,8):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)
            elif "14513" in pag:
                for i in range(0,13):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)
            else:
                for i in range(0,2):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)
    def parse(self, response):
        data = json.loads(response.text)
        for part_datail in data['infolist']:
            url  = part_datail["url"]
            date = part_datail["daytime"]
        # dates = response.xpath("//li[@class='ewb-info-item clearfix']/span[@class='ewb-date']/text()").extract()
        # total_datas = list(zip(hrefs, dates))
            yield scrapy.Request(url, meta={"date": date}, callback=self.detail_parse,
                                 dont_filter=True)



    def detail_parse(self, response):
        tendering = GuiyangTenderItem()
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        tendering['prjct_desc'] = response.xpath("//div[@class='wenzi']/table//text()").extract()
        tendering['prvnce_name'] = "贵州省"
        tendering['latn_name'] = "贵阳市"
        tendering['release_time'] = response.meta['date']
        tendering['inter_name'] = "贵阳市公共资源交易中心"
        tendering['website'] = response.url
        tendering['crawler_time'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        tendering['tender_detail'] = "".join(response.xpath("//*/text()").extract())
        data_list1 = response.xpath("//div[@class='wenzi']/text()").extract()
        data_list2 = response.xpath("//div[@class='wenzi']//p/text()").extract()
        try:
            tendering['prjct_name'] = re.findall(r"项目名称:([\s\S]*)", string=data_list1[0])[0]
            tendering['prjct_code'] = re.findall(r"项目编号:([\s\S]*)", string=data_list1[1])[0]
            tendering['county_name'] = re.findall(r"联系地址:([\s\S]*)", string=data_list1[29])[0].replace('贵阳市','').replace('贵州省','')
            b_array = time.strptime(re.findall(r"(\d{4}年\d{1,2}月\d{1,2}日)", string=data_list1[17])[0], u"%Y年%m月%d日")
            begin_Time = time.strftime("%Y-%m-%d", b_array)
            e_time = re.findall(r"(\d{4}年\d{1,2}月\d{1,2}日)", string=data_list1[16])
            e_array = time.strptime(e_time[0], u"%Y年%m月%d日")
            end_Time = time.strftime("%Y-%m-%d", e_array)
            tendering['tender_unit'] = data_list1[28][3:].replace('采购人名称:','')
            tendering['contactor'] = \
            re.findall(r"项目联系人[\s\S]+", string=data_list1[30].replace(' ', '').replace('\n', ''))[0].replace('项目联系人:','')
            tendering['contact_phone'] = re.findall(r"联系电话:([\s\S]*)", string=data_list1[31])[0].replace('联系电话:','')
            tendering['purchase_money'] = re.findall(r"采购预算:([\s\S]*)元", string=data_list1[7])[0].replace(':','').replace('采购预算:','')+'元'
            tendering['agent_unit'] = data_list1[33][12:]
            tendering['agent_contactor'] = re.findall(r"联系人:([\s\S]*)", string=data_list1[35])[0]
            tendering['agent_phone'] = re.findall(r"联系电话:([\s\S]*)", string=data_list1[36])[0].replace(':','')
            tendering['bidder_req'] = re.findall(r"投标供应商资格要求([\s\S]*)", string=data_list1[9] + data_list1[10])
            tendering['tender_note'] = re.findall(r"获取招标文件信息:[\s\S]+",
                                                  string=data_list1[11] + data_list1[12] + data_list1[13] + data_list1[
                                                      14] + data_list1[15])[0]
            tendering['open_note'] = data_list1[16] + data_list1[17] + data_list1[18]
        except:
            tendering['prjct_name'] =  re.findall(r"项目名称:([\s\S]*)", string=data_list2[0])[0]
            tendering['prjct_code'] =  re.findall(r"项目编号:([\s\S]*)", string=data_list2[1])[0]
            tendering['county_name'] = re.findall(r"联系地址:([\s\S]*)", string=data_list2[29])[0].replace('贵阳市','').replace('贵州省','')
            b_array = time.strptime(re.findall(r"(\d{4}年\d{1,2}月\d{1,2}日)", string=data_list2[17])[0], u"%Y年%m月%d日")
            begin_Time = time.strftime("%Y-%m-%d", b_array)
            e_time = re.findall(r"(\d{4}年\d{1,2}月\d{1,2}日)", string=data_list2[16])
            e_array = time.strptime(e_time[0], u"%Y年%m月%d日")
            end_Time = time.strftime("%Y-%m-%d", e_array)
            tendering['tender_unit'] = data_list2[28][3:].replace('采购人名称:','')
            tendering['contactor'] = \
            re.findall(r"项目联系人[\s\S]+", string=data_list2[30].replace(' ', '').replace('\n', ''))[0].replace('项目联系人:','')
            tendering['contact_phone'] = re.findall(r"联系电话:([\s\S]*)", string=data_list2[31])[0].replace('联系电话:','')
            tendering['purchase_money'] = re.findall(r"采购预算([\s\S]+?)元", string=data_list2[7])[0].replace(':','').replace('采购预算:','')+'元'
            tendering['agent_unit'] = data_list2[33][12:]
            tendering['agent_contactor'] = re.findall(r"联系人([\s\S]+)", string=data_list2[35])[0]
            tendering['agent_phone'] = re.findall(r"联系电话([\s\S]+)", string=data_list2[36])[0].replace(':','')
            tendering['bidder_req'] = re.findall(r"投标供应商资格要求([\s\S]+)", string=data_list2[9] + data_list2[10])[0]
            tendering['tender_note'] = re.findall(r"获取招标文件信息:([\s\S]+)",string=data_list2[11] + data_list2[12] +
                                                                             data_list2[13] + data_list2[14] + data_list2[15])[0]
            tendering['open_note'] = data_list2[16] + data_list2[17] + data_list2[18]
        tendering['begin_time'] = begin_Time
        tendering['end_time'] = end_Time
        tab2 = "".join(response.xpath("//div[@id='zoom']/table//tr/td/text()").extract())
        enum = len(response.xpath("//div[@id='zoom']/table/tr").extract()) - 1
        if enum >= 2:
            money_list = re.findall(r"预算([\s\S]+?)元", string=tab2)
            tendering['money_num'] = enum
            if len(money_list) == None:
                tendering['purchase_money_all'] = ''
            else:
                tendering['purchase_money_all'] = ("@_@".join(list(map(lambda x: x+'元', money_list)))).replace('为','').replace('金额','').replace('：','')
        else:
            tendering['purchase_money_all'] = ''
            tendering['money_num'] =  1
        yield tendering





'''
'。 （1）1.5mm厚铝板Ⅴ类（大角度反光膜）835.04@_@： （1）H=3m（直埋式）立柱式 972.60@_@： （1）10×10m跨标志杆(三柱)127407.60@_@（1）拆除标志牌＜2㎡：80.00'
'''


