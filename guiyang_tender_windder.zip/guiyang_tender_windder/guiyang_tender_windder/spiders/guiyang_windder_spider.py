# -*- coding: utf-8 -*-
import datetime
import json
import re
import time

import scrapy

from guiyang_tender_windder.items import GuiyangWindderItem


class GuiyangWindderSpiderSpider(scrapy.Spider):
    name = 'guiyang_windder_spider'
    allowed_domains = ['ggzy.guiyang.gov.cn/c14527/index.html']
    start_urls = ['http://ggzy.guiyang.gov.cn/c14527/index.html/']

    def start_requests(self):
        start_urls = [
            'http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14527&pageno={}',
            'http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14528&pageno={}',
            'http://ggzy.guiyang.gov.cn/gygov/openapi/info/ajaxpagelist.do?pagesize=15&channelid=14529&pageno={}']
        for pag in start_urls:
            if "14527" in pag:
                # for i in range(0,10):
                for i in range(1,105):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)
            if "14528" in pag:
                for i in range(0,65):
                # for i in range(61,62):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)
            else:
                for i in range(0,12):
                # for i in range(0,1):
                    i = i + 1
                    start_url = pag.format(i)
                    yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        data = json.loads(response.text)
        for part_datail in data['infolist']:
            url = part_datail["url"]
            date = part_datail["daytime"]
            yield scrapy.Request(url, meta={"date": date}, callback=self.detail_parse,
                                 dont_filter=True)

    def detail_parse(self, response):
        tendering = GuiyangWindderItem()
        tendering['prvnce_name'] = "贵州省"
        tendering['latn_name'] = "贵阳市"
        tendering['inter_name'] = "贵州省公共资源交易中心"
        tendering['website'] = response.url
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        tendering['release_time'] = response.meta['date']

        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        data_list1 = response.xpath("//div[@class='wenzi']/text()").extract()
        if re.findall(r"项目名称：([\s\S]*)", string=data_list1[0]):
                tendering['prjct_name']  = re.findall(r"项目名称：([\s\S]*)", string=data_list1[0])[0]
                tendering['prjct_code'] = re.findall(r"项目编号：([\s\S]*)", string=data_list1[1])[0]
                tendering['tender_unit'] = re.findall(r"采购人名称：([\s\S]*)", string=data_list1[15])[0]
                tendering['county_name'] = re.findall(r"采购人联系地址：([\s\S]*)", string=data_list1[16])[0]
                tendering['contactor']  = re.findall(r"采购人联系人：([\s\S]*)", string=data_list1[17])[0]
                tendering['contact_phone'] = re.findall(r"采购人联系电话：([\s\S]*)", string=data_list1[18])[0]
                tendering['agent_unit'] = re.findall(r"采购代理机构全称：([\s\S]*)", string=data_list1[19])[0]
                tendering['agent_contactor'] = re.findall(r"采购代理机构联系人：([\s\S]*)", string=data_list1[21])[0]
                tendering['agent_phone'] = re.findall(r"采购代理机构联系电话：([\s\S]*)", string=data_list1[22])[0]
                e_array = time.strptime(re.findall(r"评审时间：([\s\S]*)", string=data_list1[9])[0], u"%Y年%m月%d日")
                begin_time = time.strftime("%Y-%m-%d", e_array)
                tendering['begin_time'] =  begin_time
                e_array = time.strptime(re.findall(r"定标日期：([\s\S]*)", string=data_list1[12])[0], u"%Y年%m月%d日")
                bid_time = time.strftime("%Y-%m-%d", e_array)
                tendering['bid_time']   = bid_time
                e_array = time.strptime(re.findall(r"定标日期：([\s\S]*)", string=data_list1[12])[0], u"%Y年%m月%d日")
                bid_time = time.strftime("%Y%m", e_array)
                tendering['bid_month'] = bid_time
        elif response.xpath("//p[contains(text(),'项目名称：')]/text()"):
                data_list2 = response.xpath("//p/text()").extract()
                data_list3 = response.xpath("//p[2]/text()").extract()
                tendering['prjct_name']  = re.findall(r"项目名称：([\s\S]*)", string=data_list2[0])[0]
                tendering['prjct_code']  = re.findall(r"项目编号：([\s\S]*)", string=data_list2[1])[0]
                tendering['tender_unit'] = re.findall(r"采购人名称：([\s\S]*)",string=data_list3[1])[0]
                tendering['county_name'] = re.findall(r"采购人联系地址：([\s\S]*)",string=data_list3[2])[0].replace('贵州省','').replace('贵阳市','')
                tendering['contactor'] = re.findall(r"采购人联系人：([\s\S]*)", string=data_list3[3])[0]
                tendering['contact_phone']   =  re.findall(r"采购人联系电话：([\s\S]*)", string=data_list3[4])[0]
                tendering['agent_unit'] = re.findall(r"采购代理机构全称：([\s\S]*)", string=data_list3[5])[0]
                tendering['agent_contactor'] = re.findall(r"采购代理机构联系人：([\s\S]*)", string=data_list3[7])[0]
                tendering['agent_phone'] = re.findall(r"采购代理机构联系电话：([\s\S]*)", string=data_list3[8])[0]
                tendering['begin_time'] = time.strftime("%Y-%m-%d", time.strptime(re.findall(r"评审时间：([\s\S]*)", string=data_list2[9])[0], u"%Y年%m月%d日"))
                tendering['bid_time'] = time.strftime("%Y-%m-%d", time.strptime(re.findall(r"定标日期：([\s\S]*)", string=data_list2[12])[0], u"%Y年%m月%d日"))
                tendering['bid_month'] = time.strftime("%Y%m", time.strptime(re.findall(r"定标日期：([\s\S]*)", string=data_list2[12])[0], u"%Y年%m月%d日"))
        elif response.xpath("//span[contains(text(),'项目名称：')]"):
                tendering['prjct_name']  = response.xpath("//span[contains(text(),'项目名称：')]/following-sibling::span/text()").extract()[0]
                tendering['prjct_code']  = response.xpath("//span[contains(text(),'项目编号：')]/following-sibling::span/text()").extract()[0]
                tendering['tender_unit'] = response.xpath("//p[2]/span[3]").extract()[0]
                tendering['county_name'] = response.xpath("//span[contains(text(),'采购人联系地址：')]/following-sibling::span/text()").extract()[0].replace('贵州省','').replace('贵阳市','')
                tendering['contactor'] = response.xpath("//span[contains(text(),'采购人联系人：')]/following-sibling::span/text()").extract()[0]
                tendering['contact_phone']   = response.xpath("//span[contains(text(),'采购人联系电话：')]/following-sibling::span/text()").extract()[0]
                tendering['agent_unit']  = response.xpath("//span[contains(text(),'采购代理机构全称：')]/text()").extract()[0].replace('、采购代理机构全称：','')
                tendering['agent_contactor'] = response.xpath("//span[contains(text(),'采购代理机构联系人：')]/text()").extract()[0].replace('、采购代理机构联系人：','')
                tendering['agent_phone'] = response.xpath("//span[contains(text(),'采购代理机构联系电话：')]/text()").extract()[0].replace('、采购代理机构联系电话：', '')
                tendering['begin_time'] = time.strftime("%Y-%m-%d", time.strptime(response.xpath("//span[contains(text(),'评审时间：')]/text()").extract()[0].replace('、评审时间：', ''), u"%Y年%m月%d日"))
                tendering['bid_time'] = time.strftime("%Y-%m-%d", time.strptime(response.xpath("//span[contains(text(),'定标日期：')]/text()").extract()[0].replace('、定标时间：', ''),u"%Y年%m月%d日"))
                tendering['bid_month'] =  time.strftime("%Y%m", time.strptime(response.xpath("//span[contains(text(),'定标日期：')]/text()").extract()[0].replace('、定标时间：', ''),u"%Y年%m月%d日"))

        tendering['winbidder_detail'] = "".join(response.xpath("//*/text()").extract())

        rows = len(response.xpath("//div[@id='zoom']//table//tr").extract())
        if rows == 2:
            data = response.xpath("//div[@id='zoom']//table//tr[2]//td/text()").extract()
            tendering['winbidder_unit'] = data[1]
            tendering['winbidder_money'] = data[4] + '元'
            tendering['winbidder_unit_all'] = 1
            tendering['winbidder_money_all'] = ''
            tendering['money_num'] = 1
        else:
            tendering['money_num'] = rows - 1
            unit_list = []
            money_list = []
            for i in range(2,rows+1):
                data =  response.xpath("//div[@id='zoom']//table//tr[{}]//td/text()".format(i)).extract()
                unit_list.append(data[1])
                money_list.append(data[4]+"元")
            tendering['winbidder_unit'] = ''
            tendering['winbidder_money'] = ''
            tendering['winbidder_unit_all'] = "@_@".join(unit_list)
            tendering['winbidder_money_all'] = "@_@".join(money_list)
        yield tendering
'''
http://ggzy.guiyang.gov.cn/c14527/20180929/i1807202.html
'''



