from scrapy import cmdline
cmdline.execute("scrapy crawl haerbin_tender_spider".split())