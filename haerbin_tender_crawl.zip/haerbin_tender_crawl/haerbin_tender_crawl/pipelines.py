# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from haerbin_tender_crawl.settings import mysql_host,mysql_port,mysql_user,mysql_passwd,mysql_db
import re
import MySQLdb
import hashlib
from twisted.enterprise import adbapi

class HaerbinTenderCrawlPipeline(object):
    def open_spider(self,spider):
        self.dbpool = adbapi.ConnectionPool('MySQLdb',host= mysql_host, port=mysql_port,user=mysql_user, passwd=mysql_passwd, db=mysql_db, charset="utf8",use_unicode=True)
        # self.primary_key = 1000000000
    def close_spider(self,spider):
        self.dbpool.close()
    def process_item(self,item,spider):
        self.dbpool.runInteraction(self.insert,item)

    def insert(self,tx,item):
        # self.primary_key += 1
        sha = hashlib.sha1((item["tender_detail"] + str(item["date_id"])).encode())
        hexdigest_ = sha.hexdigest()

        insert_sq1_detail_sql = 'insert into ti_tender_detail_detail_day_srz_haerbin(date_id,hexdigest,tender_detail) values( "%s","%s","%s")'
        tx.execute(insert_sq1_detail_sql, (item["date_id"], hexdigest_, item["tender_detail"]))
        print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", item)
        insert_sql = 'insert into ti_tender_detail_srz_haerbin01(' \
                     'date_id,' \
                     'prjct_name,' \
                     'prjct_code,' \
                     'prjct_desc,' \
                     'prvnce_name,' \
                     'latn_name,' \
                     'county_name,' \
                     'release_time,' \
                     'begin_time,' \
                     'end_time,' \
                     'tender_unit,' \
                     'contactor,' \
                     'contact_phone,' \
                     'purchase_money,' \
                     'agent_unit,' \
                     'agent_contactor,' \
                     'agent_phone,' \
                     'bidder_req,' \
                     'tender_note,' \
                     'open_note,' \
                     'inter_name,' \
                     'website,' \
                     'crawler_time,' \
                     'tender_detail' \
                     ') values (' \
                     '"%s","%s","%s","%s",' \
                     '"%s","%s","%s","%s","%s",' \
                     '"%s","%s","%s","%s","%s",' \
                     '"%s","%s","%s","%s","%s",' \
                     '"%s","%s","%s","%s","%s");'
        item = (item["date_id"],
                                         item["prjct_name"],
                                         item["prjct_code"],
                                         item["prjct_desc"],
                                         item["prvnce_name"],
                                         item["latn_name"],
                                         item["county_name"],
                                         item["release_time"],
                                         item["begin_time"],
                                         item["end_time"],
                                         item["tender_unit"],
                                         item["contactor"],
                                         item["contact_phone"],
                                         item["purchase_money"],
                                         item["agent_unit"],
                                         item["agent_contactor"],
                                         item["agent_phone"],
                                         item["bidder_req"],
                                         item["tender_note"],
                                         item["open_note"],
                                         item["inter_name"],
                                         item["website"],
                                         item["crawler_time"],
                                         hexdigest_
                                         )
        tx.execute(insert_sql,item)
