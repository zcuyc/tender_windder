# -*- coding: utf-8 -*-
import scrapy
import re
from haerbin_tender_crawl.items import HaerbinTenderCrawlItem
import datetime
from  urllib import parse
from selenium import  webdriver
from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals
from scrapy.selector import Selector
import time
class HaerbinTenderSpiderSpider(scrapy.Spider):
    name = 'haerbin_tender_spider'
    allowed_domains = ['hrbggzy.org.cn']

    def __init__(self):
        super(HaerbinTenderSpiderSpider,self).__init__()
        chrome_options = webdriver.ChromeOptions()
        prefs = {"profile.managed_default_content_settings.images": 2}
        chrome_options.add_experimental_option("prefs", prefs)
        chrome_options.add_argument("--referer=http://www.hljcg.gov.cn/index.jsp")
        self.client = webdriver.Chrome("E://chromedriver//chromedriver.exe",chrome_options=chrome_options)
        dispatcher.connect(self.spider_closed,signals.spider_closed)
    def spider_closed(self):
        self.client.quit()
    def start_requests(self):

        start_url = "http://www.hljcg.gov.cn/xwzs!queryXwxxqx.action?lbbh=42301"
        # http: // www.hljcg.gov.cn / xwzs!queryXwxxqx.action?lbbh = 42301

        self.client.get(start_url)
        time.sleep(2)

        self.client.add_cookie({
            "name": "JSESSIONID",
            "value": "1nscchpMptpnQsBmQhS3gmqWymtVKSJ3pZ47zYpLNgYChShPKrNp!-739007531"
        })
        self.client.get(start_url)
        time.sleep(2)
        response = Selector(text=self.client.page_source)

        origin_urls = response.css("div:contains('-')>span:nth-child(1)>a ::attr(onclick)").extract()
        result_list1 = [e.split("=\'")[1].split(";")[0] for e in origin_urls]
        result_list = [e.replace("\'", "") for e in result_list1]
        i = 0

        for origin_url in result_list:
            origin_url = parse.urljoin("http://www.hljcg.gov.cn", origin_url)
            i = i + 1
        self.client.find_element_by_xpath("//a[contains(text(),'下页')]").click()
        for i in range(41):
            time.sleep(1)
            response = Selector(text=self.client.page_source)

            origin_urls = response.css("div:contains('-')>span:nth-child(1)>a ::attr(onclick)").extract()
            result_list1 = [e.split("=\'")[1].split(";")[0] for e in origin_urls]
            result_list = [e.replace("\'", "") for e in result_list1]

            i = 0

            for origin_url in result_list:
                origin_url = parse.urljoin("http://www.hljcg.gov.cn", origin_url)

                tm = response.css("div:contains('-')>span:nth-child(2) ::text").extract()[i]
                i = i + 1
                # "http://www.hngzzx.com"+origin_url
                yield scrapy.Request(origin_url, meta={"tm": tm}, callback=self.detail_parse, dont_filter=True)

            self.client.find_element_by_xpath("//a[contains(text(),'下页')]").click()
    def detail_parse(self,response):
        tendering = HaerbinTenderCrawlItem()
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        prjct_name = response.css("p:contains('项目名称：') ::text,"
                                  "h2:contains('项目名称：') ::text"
                                  )
        tendering['prjct_name'] = ''.join(prjct_name.extract()).strip() if prjct_name else ""
        prjct_code = response.css("div.mtt>p:contains('项目编号：') ::text"
                                  )
        # "h2:contains('项目编号：') ::text"
        tendering['prjct_code'] = ''.join(prjct_code.extract()).strip() if prjct_code else ""
        prjct_desc = response.css("p:contains('招标内容：') ::text,"
                                  "p:contains('招标内容：')+table ::text")
        tendering['prjct_desc'] = ''.join(prjct_desc.extract()).strip() if prjct_desc else ""
        tendering['prvnce_name'] = "黑龙江省"
        latn_name = response.css("p:contains('采购人地址: ') ::text,"
                                 "p:contains('采购单位：')+p+p+p:contains('址') ::text,"
                                 "p:contains('采购单位：')+p:contains('址') ::text,"
                                 "p:contains('采购人：')+p+p+p:contains('址') ::text,"
                                 "p:contains('采购人：')+p:contains('址') ::text,"
                                 "p:contains('采购单位：')+p+p:contains('址') ::text,"
                                 "p:contains('采购单位：')+p+p+p+p+p+p:contains('址') ::text")
        tendering['latn_name'] = ''.join(latn_name.extract()) if latn_name else ""
        if len(response.css("p:contains('采购人地址: ') ::text,"
                            "p:contains('采购单位：')+p+p+p:contains('址') ::text,"
                            "p:contains('采购单位：')+p:contains('址') ::text,"
                            "p:contains('采购人：')+p+p+p:contains('址') ::text,"
                            "p:contains('采购人：')+p:contains('址') ::text,"
                            "p:contains('采购单位：')+p+p:contains('址') ::text,"
                            "p:contains('采购单位：')+p+p+p+p+p+p:contains('址') ::text"))>0:
               county_name = response.css("p:contains('采购人地址: ') ::text,"
                                          "p:contains('采购单位：')+p+p+p:contains('址') ::text,"
                                          "p:contains('采购单位：')+p:contains('址') ::text,"
                                          "p:contains('采购人：')+p+p+p:contains('址') ::text,"
                                          "p:contains('采购人：')+p:contains('址') ::text,"
                                          "p:contains('采购单位：')+p+p:contains('址') ::text,"
                                          "p:contains('采购单位：')+p+p+p+p+p+p:contains('址') ::text")
               tendering['county_name'] = ''.join(county_name.extract()) if latn_name else ""
        elif len(response.css("p:contains('采购人地址: ') ::text,"
                              "p:contains('采购单位：')+p+p+p:contains('址') ::text,"
                              "p:contains('采购单位：')+p:contains('址') ::text,"
                              "p:contains('采购人：')+p+p+p:contains('址') ::text,"
                              "p:contains('采购人：')+p:contains('址') ::text,"
                              "p:contains('采购单位：')+p+p:contains('址') ::text,"
                              "p:contains('采购单位：')+p+p+p+p+p+p:contains('址') ::text"))<0:
            county_name = response.css("p:contains('采购人：') ::text,"
                                "p:contains('招标人：') ::text,"
                                "p:contains('采购单位：') ::text,"
                                "p:contains('招\xa0\xa0标\xa0\xa0人：') ::text,"
                                "p:contains('采\xa0购人：') ::text")
            tendering['county_name'] = ''.join(county_name.extract()) if latn_name else ""
        release_time = response.meta["tm"]
        tendering['release_time'] = release_time
        begin_time = response.meta["tm"]
        tendering['begin_time'] = begin_time
        end_time =  response.css("p:contains('截止时间') ::text")
        tendering['end_time'] = ''.join(end_time.extract()).strip() if end_time else ""
        tender_unit = response.css("p:contains('采购人：') ::text,"
                                   "p:contains('招标人：') ::text,"
                                   "p:contains('采购单位：') ::text,"
                                   "p:contains('招\xa0\xa0标\xa0\xa0人：') ::text,"
                                   "p:contains('采\xa0购人：') ::text")
        tendering['tender_unit'] = ''.join(tender_unit.extract()) if tender_unit else ""
        contactor = response.css("p:contains('采购人：')+p+p:contains('人') ::text,"
                                 "p:contains('招标人：')+p+p:contains('人') ::text,"
                                 "p:contains('采购单位：')+p+p:contains('人') ::text,"
                                 "p:contains('采购单位联系人：') ::text,"
                                 "p:contains('招\xa0\xa0标\xa0\xa0人：')+p+p:contains('人') ::text,"
                                 "p:contains('采购单位：')+p:contains('人') ::text,"
                                 "p:contains('采\xa0购人：')+p+p:contains('人') ::text"
                                 )
        print(''.join(contactor.extract()))
        tendering['contactor'] = ''.join(contactor.extract()) if contactor else ""
        contact_phone = response.css("p:contains('采购人：')+p+p:contains('话') ::text,"
                                     "p:contains('招标人：')+p+p:contains('话') ::text,"
                                     "p:contains('采购单位：')+p+p+p:contains('话') ::text,"
                                     "p:contains('采购人：')+p+p+p:contains('话') ::text,"
                                     "p:contains('招\xa0\xa0标\xa0\xa0人：')+p+p+p:contains('话') ::text,"
                                     "p:contains('采购单位：')+p+p:contains('手机') ::text,"
                                     "p:contains('采\xa0购人：')+p+p+p:contains('话') ::text,"
                                     "p:contains('采购人：')+p+p:contains('人') ::text,"
                                     "p:contains('招标人：')+p+p:contains('人') ::text,"
                                     "p:contains('采购单位：')+p+p:contains('人') ::text,"
                                     "p:contains('采购单位联系人：') ::text,"
                                     "p:contains('招\xa0\xa0标\xa0\xa0人：')+p+p:contains('人') ::text,"
                                     "p:contains('采购单位：')+p:contains('人') ::text,"
                                     "p:contains('采\xa0购人：')+p+p:contains('人') ::text"
                                     )
        tendering['contact_phone'] = ''.join(contact_phone.extract()) if contact_phone else ""
        purchase_money = response.css("p:contains('预算') ::text,"
                                      "p:contains('资金') ::text,"
                                      "h2:contains('自筹资金：') ::text,"
                                      "p:contains('成交金额') ::text,"
                                      "tr:contains('总计')>td:nth-child(3) ::text"
                                      )
        tendering['purchase_money'] = ''.join(purchase_money.extract()) if purchase_money else ""
        agent_unit = response.css("p:contains('集中采购机构：') ::text,"
                                  "p:contains('代理公司：') ::text,"
                                  "p:contains('代理机构：') ::text,"
                                  "p:contains('招标代理：') ::text")
        tendering['agent_unit'] = ''.join(agent_unit.extract()) if agent_unit else ""
        agent_contactor = response.css("p:contains('项目联系人：') ::text,"
                                       "p:contains('代理公司：')+p+p:contains('人') ::text,"
                                       "p:contains('代理机构：')+p+p:contains('人') ::text,"
                                       "p:contains('代理机构：')+p:contains('人') ::text,"
                                       "p:contains('代理机构：')+p+p:contains('人') ::text,"
                                       "p:contains('招标代理：')+p+p:contains('人') ::text")
        tendering['agent_contactor'] = ''.join(agent_contactor.extract()) if agent_contactor else ""
        agent_phone =  response.css("p:contains('项目联系人：') ::text,"
                                    "p:contains('代理公司：')+p+p+p:contains('话') ::text,"
                                    "p:contains('代理机构：')+p+p+p:contains('话') ::text,"
                                    "p:contains('代理机构：')+p+p:contains('话') ::text,"
                                    "p:contains('招标代理：')+p+p+p:contains('话') ::text")
        tendering['agent_phone'] = ''.join(agent_phone.extract()) if agent_phone else ""
        bidder_req =response.css("p:contains('资格要求')+p ::text,"
                                 "p:contains('资格要求')+p+p ::text,"
                                 "p:contains('资格要求')+p+p+p ::text,"
			                     "p:contains('资格要求')+p+p+p+p ::text,"
			                     "p:contains('资格要求')+p+p+p+p+p ::text,"
                                 "p:contains('合格供应商必须符合下列条件：')+p ::text,"
                                 "p:contains('合格供应商必须符合下列条件：')+p+p ::text,"
                                 "p:contains('合格供应商必须符合下列条件：')+p+p+p ::text"
                                 )
        tendering['bidder_req'] = ''.join(bidder_req.extract()) if bidder_req else ""
        tender_note = response.css("p:contains('获取招标文件方式')+p ::text,"
                                   "p:contains('谈判文件获取时间、方式')+p ::text,"
                                   "p:contains('招标文件获取及报名时间、方式')+p ::text")
        tendering['tender_note']= ''.join(tender_note.extract()) if tender_note else ""
        open_note = response.css('p:contains(开标时间) ::text,'
                                 'p:contains(开标地点) ::text,'
                                 "p:contains('投标及开标地点：') ::text")
        tendering['open_note']= ''.join(open_note.extract()) if open_note else ""
        tendering['inter_name'] = "哈尔滨公共资源交易网"
        tendering['website'] = response.url
        crawler_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        tendering['crawler_time'] = int(crawler_time)
        # tender_detail = response.xpath('//*/text()')
        tender_detail =response.css("div.xxej ::text")
        tendering['tender_detail']=''.join(tender_detail.extract()).strip() if tender_detail else ""

        # tendering['tender_detail'] = tender_detail.extract().trip() if tender_detail else ""




        yield tendering
