from scrapy import cmdline
# cmdline.execute("scrapy crawl liaoning_tender_spider".split())
cmdline.execute("scrapy crawl liaoning_windder_spider".split())