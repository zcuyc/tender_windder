# -*- coding: utf-8 -*-
import datetime
import re
import time
from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals
import scrapy
from scrapy import Selector
from selenium import webdriver

from liaoning_tender.items import LiaoningTenderItem

class LiaoningTenderSpiderSpider(scrapy.Spider):
    name = 'liaoning_tender_spider'
    allowed_domains = ['gov.cn']

    def __init__(self):
        chrome_options = webdriver.ChromeOptions()
        prefs = {"profile.managed_default_content_settings.images": 2}
        chrome_options.add_experimental_option("prefs", prefs)
        # chrome_options.add_argument("--headless")
        # chrome_options.add_argument('--disable-gpu')
        # chrome_options.add_argument("--no-sandbox")
        # chrome_options.add_argument("--proxy-server=http://39.106.163.125:8123")
        self.client = webdriver.Chrome(chrome_options=chrome_options)
        super(LiaoningTenderSpiderSpider, self).__init__()
        dispatcher.connect(self.spider_closed, signals.spider_closed)

    def spider_closed(self, spider):
        self.client.quit()

    def start_requests(self):
        start_url = 'http://www.lnzc.gov.cn/SitePages/AfficheListAll1.aspx'
        self.client.get(start_url)
        for i in range(4):
            time.sleep(1)
            response = Selector(text=self.client.page_source)
            hrefs = response.xpath("//span[@class='listTitle']/a/@href").extract()
            for href in hrefs:
                if href.startswith("/oa/bs/SitePages/"):
                    url = "http://www.lnzc.gov.cn/" + href
                    yield scrapy.Request(url, callback=self.detail_parse, dont_filter=True)
            time.sleep(2)
            self.client.find_elements_by_xpath("//img[@alt='下一个']")[0].click()


    def detail_parse(self, response):
        tendering = LiaoningTenderItem()
        tendering_all_info = "".join(response.xpath("//p//text()").extract())
        tendering['name'] = "招标"
        #接口表日期
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        #省份
        tendering['prvnce_name'] = "辽宁省"
        #项目名称
        tendering['prjct_name'] = response.xpath("//div[@id='WebPartWPQ1']/h1/a/text()").extract()[0].strip().split("竞争性")[0].split("公开")[0].split("招标")[0].split("询价")[0]
        #项目编号
        prjct_code_middle = re.findall(r'LNZC201[0-9]-[0-9]{4}\(?[0-9]?\)+', response.xpath("//div[@id='WebPartWPQ1']/h1/a/text()").extract()[0])[0][:-1]
        tendering['prjct_code'] = prjct_code_middle
        #项目概述
        tendering['prjct_desc'] = tendering_all_info.split("一、采购内容")[1].split("二、")[0].strip("：").strip().strip("\r\n")
        #预算金额/分包金额/分包个数
        tendering['money_num'] = response.xpath("//tr[@class='ms-rteTableOddRow-default']/td[@class='ms-rteTableEvenCol-default'][1]/text()").extract()[-1]
        prjct_budget_money = response.xpath("//tr[@class='ms-rteTableOddRow-default']/td[@class='ms-rteTableEvenCol-default'][2]/text()").extract()
        if prjct_budget_money != []:
            purchase_money_middle = []
            for ele in prjct_budget_money:
                if ele.strip() != "":
                    purchase_money_middle.append(ele + "元")
            if len(purchase_money_middle) == 1:
                tendering['purchase_money'] = purchase_money_middle[0]
                tendering['purchase_money_all'] = ""
            else:
                tendering['purchase_money'] = ""
                tendering['purchase_money_all'] = "@_@".join(purchase_money_middle)
        else:
            tendering['purchase_money'] = ""
            tendering['purchase_money_all'] = ""
        #招标地市/招标县
        place_name = tendering_all_info.split("采购单位、采购代理机构的名称、地址和联系方式")[1].replace(" ", "").split("地址：")[1].strip().split("\r\n")[0].split("\u3000")[0]
        if "市" in place_name:
            tendering['latn_name'] = place_name.split("市")[0][-2:] + "市"
            tendering['county_name'] = place_name.split("市")[1]
        elif "省" in place_name:
            tendering['latn_name'] = "沈阳市"
            tendering['county_name'] = place_name.split("省")[1]
        else:
            tendering['latn_name'] = "沈阳市"
            tendering['county_name'] = place_name
        # 招标发布时间
        release_time_middle = response.xpath("//div[@class='subinfo']/text()").extract()[0].strip()
        tendering['release_time'] = release_time_middle.replace("年", "-").replace("月", "-").replace("日", "").replace("/", "-")
        #招标开始时间
        tendering['begin_time'] = tendering['release_time']
        #招标截止时间/开标时间与地点
        tendering['end_time'] = re.findall(r"201[0-9].{1}[0-9]{2}.{1}[0-9]{2}",tendering_all_info.split(re.findall(r"文件截止及.{2}时间：", tendering_all_info)[0])[1].split(re.findall(r"文件及.{2}地点：", tendering_all_info)[0])[0])[0].replace("年", "-").replace("月", "-").replace("/", "-")
        tendering['open_note'] = tendering_all_info.split(re.findall(r"文件截止及.{2}时间：", tendering_all_info)[0])[1].split(re.findall(r"文件及.{2}地点：", tendering_all_info)[0])[0].strip() + "辽宁省政府采购中心五楼开标会议室"
        #采购代理单位
        tendering['agent_unit'] = "辽宁省政府采购中心"
        #来源网站名称
        tendering['inter_name'] = "辽宁省政府集中采购网"
        #来源网址
        tendering['website'] = response.url
        # #爬取时间
        # tendering['crawler_time'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        #招标详情
        tendering['tender_detail'] = "".join(response.xpath("//div[@class='col-xs-12 article']//text()").extract())
        #采购单位
        tendering['tender_unit'] = tendering_all_info.split("采购单位：")[1].split("\r\n")[0].strip()
        #招标人
        tendering['contactor'] = tendering_all_info.split("联系人：")[1].split("联系电话")[0].strip().replace("\u200b", "")
        #招标人联系电话
        tendering['contact_phone'] = tendering_all_info.split("联系电话：")[1].split("集中采购机构")[0].strip().replace("\u200b","").replace("，", " ")
        #代理招标人
        tendering['agent_contactor'] = tendering_all_info.split("联系人：")[2].split("联系电话")[0].strip().replace("\u200b", "").replace("、", " ")
        #代理联系电话
        agent_phone = tendering_all_info.split("联系电话：")[2].split("传真")[0].strip().replace("\u200b", "").replace("\xa0", " ")
        agent_phone_list = agent_phone.split("、")
        agent_phone_middle = []
        for ele in agent_phone_list:
            if len(ele.strip()) > 16:
                agent_phone_middle.append(ele.strip().split(" ")[0])
                agent_phone_middle.append(ele.strip().split(" ")[-1])
            else:
                agent_phone_middle.append(ele.strip())
            for i in range(len(agent_phone_middle)):
                if len(agent_phone_middle[i]) == 8:
                    agent_phone_middle[i] = "024-" + agent_phone_middle[i]
            tendering['agent_phone'] = agent_phone_middle[0] if len(agent_phone_middle) == 1 else " ".join(agent_phone_middle)
        #投标人资格要求
        tendering['bidder_req'] = tendering_all_info.split(re.findall(r"[二三]、合格.{3}的资格条件", tendering_all_info)[0])[1].split("[三四]、政府采购供应商入库须知")[0].strip()
        #领取招标文件办法
        tendering['tender_note'] = tendering_all_info.split(re.findall(r"[四五]、获取.{2}文件的时间及方式", tendering_all_info)[0])[1].split(re.findall(r"五、递交文件截止|五、递交报价文件|六、递交投标文件", tendering_all_info)[0])[0].strip()

        yield tendering
