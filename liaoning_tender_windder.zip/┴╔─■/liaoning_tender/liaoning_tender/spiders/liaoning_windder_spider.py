# -*- coding: utf-8 -*-
import datetime
import re
import time
from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals
import scrapy
from scrapy import Selector
from selenium import webdriver

from liaoning_tender.items import LiaoningWindderItem


class LiaoningWindderSpiderSpider(scrapy.Spider):
    name = 'liaoning_windder_spider'
    allowed_domains = ['gov.cn']


    def __init__(self):
        chrome_options = webdriver.ChromeOptions()
        prefs = {"profile.managed_default_content_settings.images": 2}
        chrome_options.add_experimental_option("prefs", prefs)
        # chrome_options.add_argument("--headless")
        # chrome_options.add_argument('--disable-gpu')
        # chrome_options.add_argument("--no-sandbox")
        # chrome_options.add_argument("--proxy-server=http://39.106.163.125:8123")
        self.client = webdriver.Chrome(chrome_options=chrome_options)
        super(LiaoningWindderSpiderSpider, self).__init__()
        dispatcher.connect(self.spider_closed, signals.spider_closed)

    def spider_closed(self, spider):
        self.client.quit()

    def start_requests(self):
        start_url = 'http://www.lnzc.gov.cn/SitePages/AfficheListAll2.aspx'
        self.client.get(start_url)
        for i in range(31):
            time.sleep(1)
            response = Selector(text=self.client.page_source)
            hrefs = response.xpath("//span[@class='listTitle']/a/@href").extract()
            for href in hrefs:
                if href.startswith("/oa/bs/SitePages/"):
                    url = "http://www.lnzc.gov.cn/" + href
                    if url not in ["http://www.lnzc.gov.cn//oa/bs/SitePages/AfficheDetail.aspx?infoID=5500&bidID=25760", "http://www.lnzc.gov.cn//oa/bs/SitePages/AfficheDetail.aspx?infoID=6771&bidID=27681"]:
                        yield scrapy.Request(url, callback=self.detail_parse, dont_filter=True)
            time.sleep(2)
            self.client.find_elements_by_xpath("//img[@alt='下一个']")[0].click()

    def detail_parse(self, response):
        windder = LiaoningWindderItem()
        windder_all_info = "".join(response.xpath("//div[@class='col-xs-12 article']//text()").extract())
        windder_p_info = "".join(response.xpath("//p//text()").extract())

        windder['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        windder['name'] = "中标"
        #项目名称
        windder['prjct_name'] = windder_all_info.split("项目名称：")[1].split("4、")[0].strip()
        #项目编号
        windder['prjct_code'] = windder_all_info.split(re.findall(r".{2}文件编号：", windder_all_info)[0])[1].split("3、")[0].strip()
        # 招标省份
        windder['prvnce_name'] = '辽宁省'
        # 采购代理单位
        windder['agent_unit'] = "辽宁省政府采购中心"
        # 代理联系人
        windder['agent_contactor'] = ''
        # 代理人联系方式
        windder['agent_phone'] = ''
        # 招标单位
        windder['tender_unit'] = re.findall(r"受(.*)委托?", windder_all_info)[0].split("委托")[0]
        # 开始时间
        windder['begin_time'] = ''
        # 中标发布时间
        windder['release_time'] = re.findall(r"201[7-9].[01]?[0-9].[0-3]?[0-9]", windder_p_info)[-1].replace("年","-").replace("月", "-")
        # 定标日期
        windder['bid_time'] = windder['release_time']
        # 定标月份
        windder['bid_month'] = windder['release_time'].split("-")[0] + windder['release_time'].split("-")[1]
        # 网站名称
        windder['inter_name'] = '辽宁省政府集中采购网'
        # 网站链接
        windder['website'] = response.url
        # 中标页详情
        windder['winbidder_detail'] = "".join(response.xpath("//div[@class='col-xs-12 article']//text()").extract())

        # #中标单位/联合中标单位/联合中标金额/中标个数
        winbidder_units = list(filter(lambda x: "\r\n" not in x and "废标" not in x, response.xpath("//table[1]//tr/td[2]/text()").extract()[1:]))
        winbidder_moneys = response.xpath("//table[1]//tr/td[4]//text()").extract()[1:] if response.xpath("//table[1]//tr/td[4]//text()") != [] else response.xpath("//table[1]//tr/td[3]//text()").extract()[1:]
        price_unit = "".join(response.xpath("//table[1]//tr[1]/td[4]//text()").extract()) if response.xpath("//table[1]//tr/td[4]//text()") != [] else "".join(response.xpath("//table[1]//tr[1]/td[3]//text()").extract())
        if len(winbidder_units) == 0:
            windder['winbidder_unit'] = ""
            windder['winbidder_money'] = ""
            windder['winbidder_unit_all'] = ""
            windder['winbidder_money_all'] = ""
            windder['money_num'] = ""
            windder['contact_phone'] = ""
            windder['contactor'] = ""
            windder['latn_name'] = ""
            windder['county_name'] = ""
        else:
            if len(winbidder_units) == 1:
                windder['winbidder_unit'] = winbidder_units[0] if winbidder_units[0].strip() != "" else ""
                winbidder_money_list = []
                for winbidder_money in winbidder_moneys:
                    if re.findall(r"[0-9]", winbidder_money) != []:
                        if "%" in price_unit and "%" not in winbidder_money:
                            winbidder_money_list.append(winbidder_money + "%")
                        elif "折扣率" in price_unit and "%" not in winbidder_money:
                            winbidder_money_list.append("折扣率：" + winbidder_money)
                        elif "元" in winbidder_money or "%" in winbidder_money:
                            winbidder_money_list.append(winbidder_money)
                        else:
                            winbidder_money_list.append(winbidder_money + "元")
                windder['winbidder_money'] = "".join(winbidder_money_list).replace(" ", "").replace("\xa0", "")
                windder['winbidder_unit_all'] = ""
                windder['winbidder_money_all'] = ""
                windder['money_num'] = "1" if windder['winbidder_unit'] != "" else ""
            else:
                winbidder_money_list = []
                for winbidder_money in winbidder_moneys:
                    if re.findall(r"[0-9]", winbidder_money) != []:
                        if "%" in price_unit and "%" not in winbidder_money:
                            winbidder_money_list.append(winbidder_money + "%")
                        elif "折扣率" in price_unit and "%" not in winbidder_money:
                            winbidder_money_list.append(winbidder_money + "折")
                        elif "元" in winbidder_money or "%" in winbidder_money:
                            winbidder_money_list.append(winbidder_money)
                        else:
                            winbidder_money_list.append(winbidder_money + "元")
                windder['winbidder_unit'] = ""
                windder['winbidder_money'] = ""
                windder['winbidder_unit_all'] = "@_@".join(winbidder_units)
                windder['winbidder_money_all'] = "@_@".join(winbidder_money_list).replace(" ", "").replace("\xa0", "")
                windder['money_num'] = str(len(winbidder_units))


            # 招标人
            try:
                windder['contactor'] = windder_all_info.split(re.findall(r"采购单位联系人.*?[:：]", windder_all_info)[0])[1].strip().split("\xa0")[0].split("联系")[0].split("电话")[0].split("0")[0].split("1")[0].strip()
            except:
                try:
                    contactor_middle = windder_all_info.split(re.findall(r"采购单位.*?[:：]", windder_all_info)[0])[1].replace(" ", "")
                    windder['contactor'] = contactor_middle.split(re.findall(r"联系人.*?[:：]", contactor_middle)[0])[1].strip().split("\r\n")[0].split("\xa0")[0].split("联系")[0].split("电话")[0].strip().replace("\u200b", "")
                except:
                    try:
                        contactor_middle = windder_all_info.split(re.findall(r"采购人名称[:：]", windder_all_info)[0])[1].replace(" ", "")
                        windder['contactor'] = contactor_middle.split(re.findall(r"联系人.*?[:：]", contactor_middle)[0])[1].split("\r\n")[0].split("\xa0")[0].split("联系")[0].strip().replace("\u200b", "")
                    except:
                        windder['contactor'] = ""


            # 招标人联系方式
            try:
                contact_phone_middle = windder_all_info.split(re.findall(r"采购单位联系人[:：]", windder_all_info)[0])[1]
                windder['contact_phone'] = re.findall(r"1[0-9]{10}|[0-9]{8}|024-.?[0-9]{8}", contact_phone_middle)[0].split("合同")[0].split("（")[0]
            except:
                try:
                    contact_phone_middle = windder_all_info.split(re.findall(r"采购单位联系人及联系方式[:：]", windder_all_info)[0])[1]
                    windder['contact_phone'] = re.findall(r"1[0-9]{10}|024-?.?[0-9]{8}|[0-9]{8}", contact_phone_middle)[0].split("合同")[0].split("（")[0]
                except:
                    try:
                        contact_phone_middle = windder_all_info.split(re.findall(r"采?购单位.*?[:：]", windder_all_info)[0])[1]
                        windder['contact_phone'] = contact_phone_middle.split(re.findall(r"话[：:]", contact_phone_middle)[0])[1].strip().split("\r\n")[0].split("\xa0")[0].split("辽")[0].strip().replace("\u200b", "").split("合同")[0].split("（")[0]
                    except:
                        windder['contact_phone'] = ""
            finally:
                if len(windder['contact_phone']) == 8:
                    windder['contact_phone'] = "024-" + windder['contact_phone']


            # 招标地市/招标区县
            try:
                latn_name_middle = windder_all_info.split(re.findall(r"采购单位地址[:：]", windder_all_info)[0])[1].replace(" ", "")
                place_name = latn_name_middle.split("\xa0")[0].split("辽宁省政府采购中心")[0].strip()
            except:
                try:
                    latn_name_middle = windder_all_info.split(re.findall(r"采?购单位.*?[:：]", windder_all_info)[0])[1].replace(" ","")
                    place_name = latn_name_middle.split(re.findall(r"址[:：]", latn_name_middle)[0])[1].split("\xa0")[0].split("\u3000")[0].split("辽宁省政府采购中心")[0].strip()
                except:
                    try:
                        latn_name_middle = windder_all_info.split(re.findall(r"采购人名称[:：]", windder_all_info)[0])[1].replace(" ", "")
                        place_name = latn_name_middle.split(re.findall(r"地?址[:：]", latn_name_middle)[0])[1].split("\xa0")[0].split("辽宁省政府采购中心")[0].strip()
                    except:
                        place_name = ""
            finally:
                if place_name != "":
                    if "市" in place_name:
                        windder['latn_name'] = place_name.split("市")[0][-2:] + "市"
                        windder['county_name'] = place_name.split("市")[1].split("联系人")[0].split("。")[0].split("（")[0].strip().split("本成交")[0]
                    elif "省" in place_name:
                        windder['latn_name'] = "沈阳市"
                        windder['county_name'] = place_name.split("省")[1].split("联系人")[0].split("。")[0].split("（")[0].strip().split("本成交")[0]
                    else:
                        windder['latn_name'] = "沈阳市"
                        windder['county_name'] = place_name.split("联系人")[0].split("。")[0].split("（")[0].strip().split("本成交")[0]
                else:
                    windder['latn_name'] = ""
                    windder['county_name'] = ""
        yield windder


