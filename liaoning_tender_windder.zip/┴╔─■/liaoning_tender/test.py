import re
s = "hwuohvnksn oushi"
print(s[-2:])
