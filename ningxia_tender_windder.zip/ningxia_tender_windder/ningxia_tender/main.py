from scrapy import cmdline
cmdline.execute("scrapy crawl ningxia_tender_spider".split())
cmdline.execute("scrapy crawl ningxia_windder_spider".split())