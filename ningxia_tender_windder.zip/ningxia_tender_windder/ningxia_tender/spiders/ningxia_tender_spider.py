# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from ningxia_tender.items import NingxiaTenderItem

class NingxiaTenderSpiderSpider(scrapy.Spider):
    name = 'ningxia_tender_spider'
    allowed_domains = ['www.nxggzyjy.org/ningxiaweb/002/002002/002002001/listPage.html']
    start_urls = ['http://www.nxggzyjy.org/']

    def start_requests(self):
        # 39页
        for i in range(10):
            i = i + 1
            start_url = "http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/{}.html".format(i)
            yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        main_url = "http://www.nxggzyjy.org"
        hrefs = response.xpath("//div[@class='ewb-info-a']/a/@href").extract()
        dates = response.xpath("//li[@class='ewb-info-item clearfix']/span[@class='ewb-date']/text()").extract()
        titles = response.xpath("//div[@class='ewb-info-a']/a/text()").extract()
        total_datas = list(zip(hrefs, dates,titles))
        for e in total_datas:
            if "招标公告" in e[2]:
                url = main_url + e[0]
                date = e[1]
                title = e[2]
                yield scrapy.Request(url, meta={"date": date,"title":title}, callback=self.detail_parse,
                                     dont_filter=True)
            else:
                continue

    def detail_parse(self, response):
        tendering = NingxiaTenderItem()
        tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
        # 项目名称
        prjct_name = response.meta['title'].replace('招标公告','').replace('公开方式','').replace('公开','')
        tendering['prjct_name'] = re.split("]", string=prjct_name)[2]
        # 招标编号
        try:
           prjct_code_test = re.split("\n", string=re.split("项目编号：|招标文件编号：|招标编号", string="".join(response.xpath("//*/text()").extract()))[1])[0]
           prjct_code = prjct_code_test if prjct_code_test else ""
        except:
           prjct_code_test = re.split("\n",string= re.split("文件编号|采购项目编号：|采购编号|委托代理编号：|计划编号：|采购代理编号：|采购代理机构编号",string="".join(response.xpath("//*/text()").extract()))[1])[0]
           prjct_code = prjct_code_test if prjct_code_test else ""
        tendering['prjct_code'] = prjct_code.replace("：",'').replace(":","").replace('\t','').replace(' ','').replace('；','')
        # print('*************************')
        # print(tendering['prjct_code'])
        # print('#########################')
        tendering['prjct_desc'] = "xxx"
        tendering['prvnce_name'] = "宁夏回族自治区"
        tendering['latn_name'] = "宁夏回族自治区"
        if  len(re.split("采购单位及代理机构联系方式", string="".join(response.xpath("//*/text()").extract()))) > 1:
            country_list_1 = re.split("\n", string=re.split("采购单位及代理机构联系方式", string="".join(response.xpath("//*/text()").extract()).replace("\xa0",""))[1])[:9]
            country_list = [x.strip() for x in country_list_1 if x.strip() != '']
            if  '地址' in  country_list[2]:
                try:
                    tendering['county_name'] = country_list[2].split("：")[1]
                except:
                    tendering['county_name'] = '第一模板'
                tendering['tender_unit']   =  country_list[1].split("：")[1]
                tendering['contactor'] = re.sub(r'[0-9]*','',string=country_list[3].split("：")[1]).replace('电话','').replace('-','')
                tendering['contact_phone'] =  "".join(re.findall(r'([0-9]*)', string=country_list[3].split("：")[1]))
                tendering['agent_unit'] = country_list[5].split("：")[1]
                if "联系人" in country_list[7]:
                    tendering['agent_contactor'] =  re.sub(r'[0-9]*','',string=country_list[7].split("：")[1]).replace('电话','').replace('-','')
                    tendering['agent_phone'] =   "".join(re.findall(r'([0-9]*)', string=country_list[7].split("：")[1]))
                elif '联系人' in country_list[6]:
                    tendering['agent_contactor'] = re.sub(r'[0-9]*','',string=country_list[6].split("：")[1]).replace('电话','').replace('-','')
                    tendering['agent_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[6].split("：")[1]))
                elif '联系人' in country_list[5]:
                    tendering['agent_contactor'] = re.sub(r'[0-9]*','',string=country_list[5].split("：")[1]).replace('电话','').replace('-','')
                    tendering['agent_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[5].split("：")[1]))
            elif "联系人" in country_list[2]:
                tendering['county_name'] = country_list[3].split("：")[1]
                tendering['tender_unit'] = country_list[1].split("：")[1]
                tendering['contactor'] = re.sub(r'[0-9]*', '', string=country_list[2].split("：")[1]).replace('电话','')
                tendering['contact_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[2].split("：")[1]))
                tendering['agent_unit'] = country_list[5].split("：")[1]
                if '联系人' in country_list[6] and '电话' in country_list[6]:
                    tendering['agent_contactor'] = re.sub(r'[0-9]*', '', string=country_list[6].split("：")[1])
                    tendering['agent_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[6].split("：")[1]))
                elif '联系人' in country_list[6] and '电话' in country_list[5] :
                    tendering['agent_contactor'] = country_list[5].split("：")[1]
                    tendering['agent_phone'] = country_list[6].split("：")[1]
                else:
                    tendering['agent_contactor'] = re.sub(r'[0-9]*', '', string=country_list[5].split("：")[1])
                    tendering['agent_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[5].split("：")[1]))
            else:
                tendering['county_name'] = '第一模板有误'
                tendering['tender_unit'] = '第一模板有误'
                tendering['contactor'] = '第一模板有误'
                tendering['contact_phone'] = '第一模板有误'
                tendering['agent_unit'] = '第一模板有误'
                tendering['agent_contactor'] = '第一模板有误'
                tendering['agent_phone'] = '第一模板有误'
        elif len(re.split("采 购 机 关", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))) > 1 :
            country_list_1 = re.split("\n", string=re.split("采 购 机 关", string="".join(response.xpath("//*/text()").extract()).replace("\xa0", ""))[1])[:12]
            country_list = [x.strip() for x in country_list_1 if x.strip() != '']
            tendering['county_name'] = '模板暂无'
            tendering['tender_unit'] = country_list[0].split('：')[1]
            tendering['contactor'] = country_list[1].split('：')[1].replace('电话','').replace('-','')
            tendering['contact_phone'] = country_list[1].split('：')[2]
            tendering['agent_unit'] = country_list[2].split('：')[1]
            tendering['agent_contactor'] = country_list[4].split('：')[1].replace('电话','').replace('-','')
            tendering['agent_phone'] = country_list[4].split('：')[2]
        elif len(re.split("联系方式", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))) > 5 :
            country_list_1 = re.split("\n", string=re.split("联系方式", string="".join(response.xpath("//*/text()").extract()).replace("\xa0",""))[1])[:12]
            country_list = [x.strip() for x in country_list_1 if x.strip() != '']
            if '采购单位' in country_list[1]:
                tendering['county_name'] = country_list[2].split("：")[1].replace('地址','')
                tendering['tender_unit'] = country_list[1].split("：")[1]
                tendering['agent_unit'] = country_list[1].split("：")[2]
                tendering['contactor'] = country_list[3].split("：")[1].replace('联 系 人','')
                tendering['contact_phone'] = country_list[4].split("：")[1].replace('联系电话','')
                tendering['agent_phone'] = country_list[4].split("：")[2]
            elif '采购人' in country_list[1]:
                tendering['county_name'] = "（采购人）第四模板"
                tendering['tender_unit'] = country_list[1].split("：")[1]
                tendering['contactor'] = country_list[3].split("：")[1].replace('电话','')
                tendering['contact_phone'] = country_list[3].split("：")[2]
                tendering['agent_unit'] = country_list[4].split("：")[1]
                tendering['agent_phone'] = country_list[6].split("：")[2]
            elif '名称' in country_list[1]:
                tendering['county_name'] = country_list[2].split("：")[1]
                tendering['tender_unit'] = country_list[1].split("：")[1]
                tendering['contactor'] = country_list[3].split("：")[1]
                tendering['contact_phone'] = country_list[4].split("：")[1]
                tendering['agent_unit'] = country_list[5].split("：")[1]
                tendering['agent_phone'] = country_list[8].split("：")[1]
            elif '购人' in country_list[2]:
                tendering['county_name'] =country_list[3].split("：")[1]
                tendering['tender_unit'] = country_list[2].split("：")[1]
                tendering['contactor'] = country_list[5].split("：")[1]
                tendering['contact_phone'] = country_list[6].split("：")[1]
                tendering['agent_unit'] = country_list[7].split("：")[1]
                tendering['agent_phone'] = country_list[11].split("：")[1]
            elif '招标人' in country_list[0]:
                tendering['county_name'] = country_list[3].split("：")[1]
                tendering['tender_unit'] = country_list[0].split("：")[1]
                tendering['contactor'] = re.sub(r'[0-9]*', '', string=country_list[1].split("：")[1]).replace('联系电话','')
                tendering['contact_phone'] = "".join(re.findall(r'([0-9]*)', string=country_list[1].split("：")[1]))
                tendering['agent_unit'] = country_list[2].split("：")[1]
                tendering['agent_contactor'] = re.sub(r'[0-9]*', '', string=country_list[4].split("：")[1]).replace('联系电话','')
                tendering['agent_phone'] ="".join(re.findall(r'([0-9]*)', string=country_list[4].split("：")[2])).replace('电子邮箱','')
            else:
                tendering['county_name'] = '第二模板有误'
                tendering['tender_unit'] = '第二模板有误'
                tendering['contactor'] = '第二模板有误'
                tendering['contact_phone'] = '第二模板有误'
                tendering['agent_unit'] = '第二模板有误'
                tendering['agent_contactor'] = '第二模板有误'
                tendering['agent_phone'] = '第二模板有误'
        elif len(re.split("采购方", string="".join(response.xpath("//*/text()").extract()))) > 1:
            country_list = re.split("\n", string=re.split("采购方", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))[1])[:6]
            if '联系人' in country_list[1]:
                tendering['county_name'] = '采购方第五模板'
                tendering['tender_unit'] = country_list[0].split("：")[1]
                tendering['contactor'] = country_list[1].split("：")[1].replace("联系电话","")
                tendering['contact_phone'] = country_list[1].split("：")[2]
                tendering['agent_unit'] = country_list[2].split("：")[1]
                tendering['agent_contactor'] = country_list[4].split("：")[1].replace("联系电话","")
                tendering['agent_phone'] = country_list[4].split("：")[2]
                # tendering['county_name'] ='?????'
            else:
                tendering['county_name'] = '第三模板有误'
                tendering['tender_unit'] = '第三模板有误'
                tendering['contactor'] = '第三模板有误'
                tendering['contact_phone'] = '第三模板有误'
                tendering['agent_unit'] = '第三模板有误'
                tendering['agent_contactor'] = '第三模板有误'
                tendering['agent_phone'] = '第三模板有误'
        elif len(re.split("采购人", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))[1]) > 1:
            country_list_1 =  re.split("\n", string=re.split("采购人", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))[1])[:17]
            country_list = [x.strip() for x in country_list_1 if x.strip() != '']
            if "地址" in country_list_1[1]:
                tendering['county_name'] = country_list[1].split("：")[1]
                tendering['tender_unit'] = country_list[0].split("：")[1]
                tendering['contactor'] = country_list[2].split("：")[1].replace('联系电话','')
                tendering['contact_phone'] = country_list[2].split("：")[2]
                tendering['agent_unit'] = country_list[3].split("：")[1]
                tendering['agent_contactor'] = country_list[5].split("：")[1].replace('联系电话','')
                tendering['agent_phone'] = country_list[5].split("：")[2]
            else:
                tendering['county_name'] = '没有地址第六模板'
                tendering['tender_unit'] = country_list[0].split("：")[1]
                tendering['contactor'] = country_list[1].split("：")[1].replace('联系电话', '')
                tendering['contact_phone'] = country_list[1].split("：")[2]
                tendering['agent_unit'] = country_list[2].split("：")[1]
                tendering['agent_contactor'] = country_list[3].split("：")[1].replace('联系电话','')
                tendering['agent_phone'] = country_list[3].split("：")[2]
        elif len(re.split("购单位", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))[1])>1:
            country_list_1 = re.split("\n", string=re.split("购单位", string="".join(response.xpath("//*/text()").extract()).replace('\xa0',''))[1])[:17]
            country_list = [x.strip() for x in country_list_1 if x.strip() != '']
            if  '联系人'  in country_list[1]:
                tendering['county_name'] = country_list[2].split("：")[1]
                tendering['tender_unit'] = country_list[0].split("：")[1]
                tendering['contactor'] = country_list[2].split("：")[1].replace('联系电话', '')
                tendering['contact_phone'] = country_list[2].split("：")[2]
                tendering['agent_unit'] = country_list[3].split("：")[1]
                tendering['agent_contactor'] = country_list[4].split("：")[1].replace('联系电话', '')
                tendering['agent_phone'] = country_list[4].split("：")[2]
        else:
            tendering['county_name'] = '第四模板有误'
            tendering['tender_unit'] = '第四模板有误'
            tendering['contactor'] = '第四模板有误'
            tendering['contact_phone'] = '第四模板有误'
            tendering['agent_unit'] = '第四模板有误'
            tendering['agent_contactor'] = '第四模板有误'
            tendering['agent_phone'] = '第四模板有误'

        tendering['release_time'] = 20191011
        tendering['begin_time'] = 20191012
        tendering['end_time'] = 20191013
        tendering['purchase_money'] = "xxx"
        tendering['bidder_req'] = "xxx"
        tendering['tender_note'] = "xxx"
        tendering['open_note'] = "xxx"
        tendering['inter_name'] = "xxx"
        tendering['website'] = response.url
        tendering['crawler_time'] = 20191212
        tendering['tender_detail'] = response.url
        tendering['purchase_money_all'] = '100'
        tendering['money_num'] = '200'
        # prjct_name_middle = response.xpath("//div[@class='detail_box']//div[contains(text(),'项目名称')]/text()")
        # prjct_name_middle = prjct_name_middle.extract()[0].split("项目名称")[1].strip() if prjct_name_middle else ""
        # tendering['prjct_name'] = prjct_name_middle.replace("\n", "").replace("\t", "").replace("：", "")
        # prjct_code_middle = response.xpath("//div[@class='detail_box']//div[contains(text(),'项目编号')]/text()")
        # prjct_code_middle = prjct_code_middle.extract()[0].split("项目编号")[1].strip() if prjct_code_middle else ""
        # tendering['prjct_code'] = prjct_code_middle.replace("\n", "").replace("\t", "").replace("：", "")

        yield tendering
'''

   http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/20190521/0ccb5002-cc13-4e41-9903-cbeed07f054e.html
   http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/20190513/997f49bc-ad83-4857-8424-f9bfb353ad3c.html
   http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/20190522/1b160fb7-66bf-4782-b42e-e86435428432.html
   http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/20190522/80fab1a4-7d91-45d4-9850-4fb27f8be3a3.html
   http://www.nxggzyjy.org/ningxiaweb/002/002002/002002001/20190522/80fab1a4-7d91-45d4-9850-4fb27f8be3a3.html
   
'''