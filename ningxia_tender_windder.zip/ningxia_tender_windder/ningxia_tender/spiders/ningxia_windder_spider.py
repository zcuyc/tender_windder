# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from ningxia_tender.items import NingxiaWindderItem


class NingxiaWindderSpiderSpider(scrapy.Spider):
    name = 'ningxia_windder_spider'
    allowed_domains = ['www.nxggzyjy.org/ningxiaweb/002/002002/002002003/1.html']
    start_urls = ['http://www.nxggzyjy.org/ningxiaweb/002/002002/002002003/1.html']

    def start_requests(self):
        for i in range(2):
            i = i + 1
            start_url = "http://www.nxggzyjy.org/ningxiaweb/002/002002/002002003/{}.html".format(i)
            yield scrapy.Request(start_url, callback=self.parse, dont_filter=True)

    def parse(self, response):
        main_url = "http://www.nxggzyjy.org"
        hrefs = response.xpath("//div[@class='ewb-info-a']/a/@href").extract()
        print(hrefs)
        dates = response.xpath("//li[@class='ewb-info-item clearfix']/span[@class='ewb-date']/text()").extract()
        total_datas = list(zip(hrefs, dates))
        for e in total_datas:
            url = main_url + e[0]
            date = e[1]
            yield scrapy.Request(url, meta={"date": date}, callback=self.detail_parse,
                                 dont_filter=True)
    def detail_parse(self, response):
        tendering = NingxiaWindderItem()
        tendering['date_id'] = 20181010
        tendering['prjct_name'] = "xax"
        tendering['prjct_code'] = "xax"
        tendering['prvnce_name'] = "xax"
        tendering['latn_name'] = "xax"
        tendering['county_name'] = "xax"
        tendering['release_time'] = "xax"
        tendering['tender_unit'] = "xax"
        tendering['contactor'] = "xax"
        tendering['contact_phone'] = "xax"
        tendering['agent_unit'] = "xax"
        tendering['agent_contactor'] = "xax"
        tendering['agent_phone'] = "xxx"
        tendering['winbidder_unit'] = "xxx"
        tendering['winbidder_money'] = "xxx"
        tendering['begin_time'] = "xxx"
        tendering['bid_time'] = "xxx"
        tendering['bid_month'] = "xxx"
        tendering['inter_name'] = "xxx"
        tendering['website'] = "xxx"
        tendering['winbidder_detail'] = response.url
        tendering['winbidder_unit_all'] = 'xxx'
        tendering['winbidder_money_all']= 'xxx'
        tendering['money_num'] = 'xxx'

    #     tendering = GuiyangWindderItem()
    #     tendering['date_id'] = int(datetime.datetime.now().strftime("%Y%m%d"))
    #     if response.xpath("//p[contains(text(),'项目名称：')]"):
    #         prjct_name_middle = response.xpath("//p[contains(text(),'项目名称：')]/text()")
    #         prjct_name_middle = prjct_name_middle.extract()[0] if prjct_name_middle else ""
    #         tendering['prjct_name'] = \
    #         prjct_name_middle.replace("项目名称：", "").replace("\n", "").replace("\t", "").split("、")[1]
    #         prjct_code_middle = response.xpath("//p[contains(text(),'项目编号：')]/text()")
    #         prjct_code_middle = "".join(prjct_code_middle.extract()) if prjct_code_middle else ""
    #         tendering['prjct_code'] = \
    #         prjct_code_middle.replace("\n", "").replace("\t", "").replace("项目编号：", "").split("、")[1]
    #         tendering['prvnce_name'] = "贵州省"
    #         tendering['latn_name'] = "贵阳市"
    #
    #         release_time = response.xpath("//span[contains(text(),'发布时间')]/text()")
    #         release_time = release_time.extract()[0] if release_time else ""
    #         tendering['release_time'] = release_time.replace("发布时间：", "").replace("\n", "").replace("\t", "")
    #
    #         div_all_text = "".join(response.xpath("//div[@class='detail_box']//p/text()").extract())
    #         p_all_text = div_all_text.split("采购人名称：")[1].replace("\t", "")
    #         tendering['tender_unit'] = re.split("\n+", p_all_text)[0]
    #         tendering['county_name'] = re.split("\n+", p_all_text)[1].replace("联系地址：", "")
    #         tendering['contactor'] = re.split("\n+", p_all_text)[2].replace("项目联系人：", "")
    #         tendering['contact_phone'] = re.split("\n+", p_all_text)[3].replace("联系电话：", "")
    #         agent_text = p_all_text.split("采购代理机构全称：")[1]
    #         tendering['agent_unit'] = re.split("\n+", agent_text)[0]
    #         tendering['agent_contactor'] = re.split("\n+", agent_text)[2].replace("项目联系人：", "")
    #         tendering['agent_phone'] = re.split("\n+", agent_text)[3].replace("联系电话：", "")
    #
    #         fields = response.xpath("//thead//tr//*/text()").extract()
    #         values = response.xpath("//tbody//tr//*/text()").extract()
    #
    #         middle_gys = [e for e in fields if "供应商" in e][0]
    #         middle_je = [e for e in fields if "元" in e][0]
    #         winbidder_unit = values[fields.index(middle_gys)]
    #         tendering['winbidder_unit'] = winbidder_unit
    #
    #         winbidder_money = values[fields.index(middle_je)]
    #         tendering['winbidder_money'] = winbidder_money
    #
    #         begin_time = response.xpath("//p[contains(text(),'采购日期：')]/text()")
    #         begin_time = "".join(begin_time.extract()) if begin_time else ""
    #         tendering['begin_time'] = begin_time.replace("采购日期：", "").replace("\n", "").replace("\t", "").split("、")[1]
    #         bid_time_middle = response.xpath("//p[contains(text(),'定标日期：')]/text()")
    #         bid_time_middle = "".join(bid_time_middle.extract()) if bid_time_middle else ""
    #         tendering['bid_time'] = bid_time_middle.replace("定标日期：", "").replace("\n", "").replace("\t", "").split("、")[
    #             1]
    #         tendering['bid_month'] = \
    #         bid_time_middle.replace("定标日期：", "").replace("\n", "").replace("\t", "").split("、")[1]
    #         tendering['inter_name'] = "贵州省公共资源交易中心"
    #         tendering['website'] = response.url
    #         tendering['winbidder_detail'] = "".join(response.xpath("//*/text()").extract())
    #         yield tendering
    #     elif response.xpath("//span[contains(text(),'项目名称：')]"):
    #         try:
    #
    #             prjct_name_middle = response.xpath("//span[contains(text(),'项目名称：')]/following-sibling::span/text()")
    #
    #
    #         except:
    #             tendering['prjct_name'] = \
    #             response.xpath("//span[contains(text(),'项目名称：')]/text()").extract()[0].split("项目名称：")[1]
    #         else:
    #             tendering['prjct_name'] = prjct_name_middle.extract()[0].strip().replace("\n", "").replace("\t",
    #                                                                                                        "") if prjct_name_middle else ""
    #
    #         try:
    #
    #             prjct_code_middle = response.xpath("//span[contains(text(),'项目编号')]/following-sibling::span/text()")
    #         except:
    #             try:
    #                 prjct_code_middle = response.xpath(
    #                     "//span[contains(text(),'项目序列号')]/following-sibling::span/text()")
    #             except:
    #                 prjct_code_middle = \
    #                 response.xpath("//span[contains(text(),'项目编号')]/text()").extract()[0].split("项目编号：")[1]
    #             else:
    #                 prjct_code_middle = prjct_code_middle.extract()[0].strip() if prjct_code_middle else ""
    #         else:
    #
    #             prjct_code_middle = prjct_code_middle.extract()[0].strip() if prjct_code_middle else ""
    #
    #         tendering['prjct_code'] = prjct_code_middle.replace("\n", "").replace("\t", "")
    #         tendering['prvnce_name'] = "贵州"
    #         tendering['latn_name'] = "贵阳"
    #
    #         tendering['release_time'] = \
    #         response.xpath("//span[contains(text(),'发布时间')]/text()").extract()[0].split("发布时间：")[1]
    #
    #         div_all_text = "".join(response.xpath("//div[@class='detail_box']//*/text()").extract())
    #         p_all_text = re.split("采购人名称：|采购单位:")[1].replace("\t", "")
    #         if "\n" in p_all_text:
    #
    #             tendering['tender_unit'] = re.split("\n+", p_all_text)[0]
    #             tendering['county_name'] = re.split("\n+", p_all_text)[1].replace("联系地址：", "")
    #             tendering['contactor'] = re.split("\n+", p_all_text)[2].replace("项目联系人：", "")
    #             tendering['contact_phone'] = re.split("\n+", p_all_text)[3].replace("联系电话：", "")
    #             agent_text = p_all_text.split("采购代理机构全称：")[1]
    #             tendering['agent_unit'] = re.split("\n+", agent_text)[0]
    #             tendering['agent_contactor'] = re.split("\n+", agent_text)[2].replace("项目联系人：", "")
    #             tendering['agent_phone'] = re.split("\n+", agent_text)[3].replace("联系电话：", "")
    #
    #         else:
    #             tendering['tender_unit'] = p_all_text.split("联系电话：")[0]
    #             tendering['county_name'] = p_all_text.split("联系电话：")[0]
    #             tendering['contactor'] = p_all_text.split("联系电话：")[0]
    #             tendering['contact_phone'] = p_all_text.split("联系电话：")[1].split("(二)")[0]
    #             agent_text = p_all_text.split("采购代理机构：")[1]
    #             tendering['agent_unit'] = agent_text.split("联系电话：")[0]
    #             tendering['agent_contactor'] = agent_text.split("联系电话：")[0]
    #             tendering['agent_phone'] = agent_text.split("联系电话：")[1].split("重要提示")[0]
    #
    #         tendering['winbidder_unit'] = ""
    #
    #         try:
    #             winbidder_money = \
    #             response.xpath("//span[contains(text(),'项目预算金额')]/following-sibling::span/text()").extract()[0]
    #         except:
    #             winbidder_money = response.xpath("//span[contains(text(),'项目预算金额')]/text()").extract()[0]
    #             tendering['winbidder_money'] = winbidder_money.split("项目预算金额(元)：") if winbidder_money else ""
    #         else:
    #
    #             tendering['winbidder_money'] = winbidder_money.replace("\n", "").replace("\t", "")
    #         tendering['begin_time'] = ""
    #         tendering['bid_time'] = ""
    #         tendering['bid_month'] = ""
    #         tendering['inter_name'] = "贵州省公共资源交易中心"
    #         tendering['website'] = response.url
    #         tendering['winbidder_detail'] = "".join(response.xpath("//*/text()").extract()).replace("\t", "").replace(
    #             "\n", "")
        yield tendering
