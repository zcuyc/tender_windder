import re




magnet_link =  '采 购 机 关：22sd 采 购 机 关 88 采 购 机 关 999'
# s=[a.strip() for a in x]

li = re.split('采 购 机 关',string=magnet_link)
print(li)



